# @hanamesh/devkit

HanaMesh-owned development tooling from `hanamesh-server-shared`. No runtime or third-party dependencies. Install its frozen tarball as a dev dependency (`file:vendor/hanamesh-devkit-0.1.0-rc.2.tgz`); HanaMesh vendor policy also records the exact optional peer `0.1.0-rc.2`. Distribution is authorized as recorded in LICENSE and LICENSE_RECORD.md; this does not add a standard license or authorize npm publication. Do not publish to npm or add a private registry.

The public ESM exports are `checkToolchain`, `preflight`, `runMutations` and `verifyPack`, also available at their named subpaths. `hanamesh-devkit <command> [devkit.config.mjs]` loads the matching key from the default config export. A config owns module-specific assertions, mutation targets, public API probes and exact versions. The tooling owns execution, assertions, evidence and cleanup.

```js
export default {
  'check-toolchain': {root: process.cwd(), pins: {node:'24.13.1', pnpm:'10.33.0', typescript:'5.9.3'}},
  preflight: {root: process.cwd(), validate: async root => { /* module policy */ }},
  mutations: {root: process.cwd(), cases: [{id:'guard', file:'dist/service.js', test:'test/service.test.mjs', from:'if (allowed)', to:'if (true)'}]},
  'verify-pack': {root: process.cwd(), tarball:'artifacts/module.tgz', required:['dist/index.js']}
};
```

`runMutations` first runs an unmodified baseline, then changes one isolated copy per case, emits explicit TAP, and requires a failing assertion (`not ok` and `ERR_ASSERTION`). Cases accept exact `from`/`to` or a module-owned `mutate` function. Original source/dist stays unchanged. Evidence includes baseline, each mutant and `results.json`; temporary copies are removed even on failure. `nodeArgs` supports TS loaders; `tests` supports multiple suites. Use `temporaryRoot` and `evidenceDir` under the card run directory.

`preflight` rejects engine copies at conventional `scripts/` and `tools/` filenames; thin public-entry wrappers remain allowed. Domain validation is supplied by the module. This source guard does not detect renamed or semantically disguised copies, and is not a replacement for review.

`verifyPack` checks digest (when supplied), required/forbidden entries and a module-owned archive validator. Its optional `consumer` accepts a package manifest, JavaScript public-API probe and TypeScript probe. These run in a temporary install directory with only the tarball and its declared peers; no source-tree resolver or symlink is used. Installation and typechecking errors propagate, and temporary installs are removed.

Runtime errors are **not** exported from this development package. Use `ServerError` from the separate runtime entry `@hanamesh/server-shared/errors` (exact runtime peer + vendored development install in the consuming origin). Shared's existing `SharedError`/`fail`/`safeError` behavior stays intact. Each module retains its code union, status/message mapping, subclass name and serialization. Adopting the runtime base changes runtime bytes and needs its own consumer card/version bump.

Compatibility reproduction: run `python3 scripts/devkit-compatibility.py --run-dir <card-run-dir> --node-bin <Node-24.13.1-bin-dir>` from shared. It freezes Claim and Semantic with Git archive, changes only copies, installs the devkit tarball and executes the real build/test/mutations/check/pack commands. No database or model call is made. Comparison reports archive entries, payload hashes, header fields and all changed files; package.json's new development dependency/peer is expected, and runtime files must remain identical. This proves two frozen consumers, not migration of all HanaMesh modules.
