import assert from 'node:assert/strict';
import {readdir, readFile} from 'node:fs/promises';
import {join} from 'node:path';

const runnerNames = /^(?:mutations?|preflight|verify-pack|check-toolchain|target-preflight)\.mjs$/u;

// Module-specific policy stays in its origin; copied execution engines do not.
export async function preflight({root = process.cwd(), validate} = {}) {
  for (const folder of ['scripts', 'tools']) {
    let entries;
    try { entries = await readdir(join(root, folder)); }
    catch (error) { if (error.code === 'ENOENT') continue; throw error; }
    for (const file of entries.filter(name => runnerNames.test(name))) {
      const source = await readFile(join(root, folder, file), 'utf8');
      assert.ok(source.trim().split('\n').length <= 8 &&
        /(?:@hanamesh\/devkit|packages\/devkit\/src)/u.test(source) &&
        !/node:(?:child_process|fs)|\b(?:for|while)\s*\(/u.test(source),
      `DUPLICATE_DEVKIT_TOOL ${folder}/${file}: move execution to @hanamesh/devkit; keep module policy in a named config`);
    }
  }
  if (validate) await validate(root);
  return true;
}
