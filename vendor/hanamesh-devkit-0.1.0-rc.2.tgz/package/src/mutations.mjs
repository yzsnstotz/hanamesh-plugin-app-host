import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {cp, mkdir, mkdtemp, readdir, readFile, rm, symlink, writeFile} from 'node:fs/promises';
import {existsSync} from 'node:fs';
import {join, resolve, relative, isAbsolute} from 'node:path';
import {tmpdir} from 'node:os';

export async function runMutations({root = process.cwd(), cases, baselineTests,
  nodeArgs = [], evidenceDir = join(root, 'artifacts/mutations'), temporaryRoot = tmpdir()}) {
  root = resolve(root); evidenceDir = resolve(evidenceDir); temporaryRoot = resolve(temporaryRoot);
  await mkdir(evidenceDir, {recursive: true});
  const run = (cwd, tests) => {
    const env = {...process.env};
    delete env.NODE_TEST_CONTEXT; // A harness called by node:test must start a separate test runner.
    const result = spawnSync(process.execPath, [...nodeArgs, '--test', '--test-reporter=tap', ...tests],
      {cwd, env, encoding: 'utf8', maxBuffer: 16 * 1024 * 1024});
    return {exitCode: result.status, output: `${result.stdout ?? ''}${result.stderr ?? ''}`};
  };
  const baseline = run(root, baselineTests ?? [...new Set(cases.flatMap(item => item.tests ?? [item.test]))]);
  await writeFile(join(evidenceDir, 'baseline.tap'), baseline.output);
  assert.equal(baseline.exitCode, 0, `MUTATION_BASELINE: ${baseline.output}`);
  const results = [];
  for (const item of cases) {
    const id = item.id ?? item.name;
    assert.match(id, /^[a-zA-Z0-9_-]+$/u);
    assert.ok(item.file && !isAbsolute(item.file) && !item.file.split(/[\\/]/u).includes('..'), 'mutation file must stay in root');
    const work = await mkdtemp(join(temporaryRoot, 'devkit-mut-'));
    try {
      const include = path => {
        const rel = relative(root, path);
        return !rel.split(/[\\/]/u).some(part => ['.git', 'node_modules', 'artifacts', '.tmp'].includes(part)) &&
          !path.startsWith(work) && (path === root || !path.startsWith(evidenceDir));
      };
      for (const name of await readdir(root)) {
        const path = join(root, name);
        if (include(path)) await cp(path, join(work, name), {recursive: true, filter: include});
      }
      if (existsSync(join(root, 'node_modules'))) await symlink(join(root, 'node_modules'), join(work, 'node_modules'), 'dir');
      const target = join(work, item.file), original = await readFile(target, 'utf8');
      if (!item.mutate) assert.equal(original.split(item.from).length - 1, 1, `MUTATION_ANCHOR ${id}`);
      const changed = item.mutate ? item.mutate(original) : original.replace(item.from, item.to);
      assert.notEqual(changed, original, `MUTATION_ANCHOR ${id}`);
      await writeFile(target, changed);
      const result = run(work, item.tests ?? [item.test]), assertionFailure = /ERR_ASSERTION/u.test(result.output);
      const detected = result.exitCode !== null && result.exitCode !== 0 && /not ok/u.test(result.output) && assertionFailure;
      await writeFile(join(evidenceDir, `${id}.tap`), result.output);
      const receipt = {id, baselineExit: 0, mutantExit: result.exitCode, detected, assertionFailure};
      results.push(receipt);
      assert.ok(detected, `MUTATION_NOT_ASSERTION ${id}: ${result.output.slice(-1600)}`);
      console.log(JSON.stringify(receipt));
    } finally { await rm(work, {recursive: true, force: true}); }
  }
  await writeFile(join(evidenceDir, 'results.json'), JSON.stringify({baseline: {exitCode: 0}, results}, null, 2) + '\n');
  return results;
}
