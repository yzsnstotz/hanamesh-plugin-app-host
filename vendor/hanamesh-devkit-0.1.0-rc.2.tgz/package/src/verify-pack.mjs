import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {mkdir, mkdtemp, readFile, rm, writeFile} from 'node:fs/promises';
import {join, resolve} from 'node:path';
import {tmpdir} from 'node:os';

export async function verifyPack({root = process.cwd(), tarball, sha256, required = [],
  forbidden = /node_modules\/|vendor\/|test\/|artifacts\//u, validate, consumer,
  temporaryRoot = tmpdir()}) {
  root = resolve(root); tarball = resolve(root, tarball);
  const digest = createHash('sha256').update(await readFile(tarball)).digest('hex');
  if (sha256) assert.equal(digest, sha256, 'PACK_DIGEST_MISMATCH');
  const entries = execFileSync('tar', ['-tzf', tarball], {encoding: 'utf8'}).trim().split('\n');
  for (const file of required) assert.ok(entries.includes(`package/${file}`), `PACK_MISSING ${file}`);
  if (forbidden) for (const file of entries) assert.doesNotMatch(file, forbidden);
  const read = file => execFileSync('tar', ['-xOf', tarball, `package/${file}`]);
  if (validate) await validate({entries, read, sha256: digest});
  if (consumer) {
    const work = await mkdtemp(join(temporaryRoot, 'devkit-pack-'));
    try {
      await writeFile(join(work, 'package.json'), JSON.stringify(consumer.packageJson));
      await writeFile(join(work, '.npmrc'), 'strict-peer-dependencies=false\n');
      execFileSync('pnpm', ['install', '--prefer-offline', '--frozen-lockfile=false'],
        {cwd: work, stdio: 'pipe', env: {...process.env, npm_config_cache: join(work, 'npm-cache')}});
      // Consumer resolves only the installed tarball: neither module source nor dist is in this directory.
      await writeFile(join(work, 'check.mjs'), consumer.javascript);
      process.stdout.write(execFileSync(process.execPath, ['check.mjs'], {cwd: work, encoding: 'utf8'}));
      if (consumer.typescript) {
        await writeFile(join(work, 'consumer.ts'), consumer.typescript);
        execFileSync(join(root, 'node_modules/.bin/tsc'), ['--strict', '--skipLibCheck', 'false', '--target', 'ES2024',
          '--module', 'NodeNext', '--moduleResolution', 'NodeNext', '--noEmit', 'consumer.ts'], {cwd: work, stdio: 'pipe'});
      }
    } finally { await rm(work, {recursive: true, force: true}); }
  }
  console.log(JSON.stringify({event: 'pack_verified', sha256: digest, entries: entries.length, artifactConsumer: Boolean(consumer)}));
  return {sha256: digest, entries};
}
