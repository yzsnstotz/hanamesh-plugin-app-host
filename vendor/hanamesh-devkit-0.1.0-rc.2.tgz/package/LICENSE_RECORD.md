# Devkit license and distribution record

| Name | Version | License / authorization | Source | Purpose |
| --- | --- | --- | --- | --- |
| @hanamesh/devkit | 0.1.0-rc.2 | SEE LICENSE IN LICENSE; HanaMesh-owned distribution authorized in D-2026-10-05-02 and D-2026-10-05-16; no new standard license or relicensing grant | yzsnstotz/hanamesh-server-shared, packages/devkit; baseline b2b5c9bb7faa990e3eb9f99007abd6427d62e88b / rc.1 | Development preflight, mutation execution, package verification and toolchain checks |

The original rc.1 manifest contained private=true and license=UNLICENSED, with no
standalone LICENSE text. Those obsolete metadata fields are superseded for rc.2
by private=false and this explicit distribution notice. The old tarball and
records remain unchanged. This package has no dependency or peerDependency and
ships no third-party runtime or compiler. It uses Node standard-library APIs;
Node itself is supplied by the consumer and is not bundled here.

Authority: the project owner's 2026-10-05 instruction to correct lib-provision
and devkit vendor metadata under D-2026-10-05-02, recorded in D-2026-10-05-16.
The notice does not extend that instruction into a new general license.
