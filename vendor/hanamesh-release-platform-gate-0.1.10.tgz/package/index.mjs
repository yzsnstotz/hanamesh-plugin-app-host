import {readFile, mkdir, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve, dirname, posix, relative, sep} from 'node:path';
import {isDeepStrictEqual} from 'node:util';
import mapWorkspaces from '@npmcli/map-workspaces';
import {Parser} from 'tar';
import YAML from 'yaml';
import semver from 'semver';
import npa from 'npm-package-arg';

export const DEPENDENCY_SHAPE_CONTRACT=Object.freeze({id:'dependency-shapes-v1',document:'DEPENDENCY_SHAPES.md',unsupportedCode:'UNSUPPORTED_DEPENDENCY_SHAPE'});
export const INVARIANT='DSH_PNPM_PLATFORM_CLOSURE';
export const REASON='Correctness invariant; cannot be disabled: DSH bundled pnpm 11.7.0 may not exit after processing inapplicable platform optional packages. All OS/CPU/libc targets must use one platform-neutral install dependency closure.';
// Visible conservative name classification. It complements actual manifest/lock metadata.
export const PLATFORM_TOKEN=/(?:^|[-_/])(?:darwin|macos|win32|windows|linux|android|freebsd|openbsd|netbsd|sunos|aix|haiku|os400|cygwin|arm64|aarch64|arm|x64|x86_64|ia32|x86|ppc64|s390x|riscv64|loong64|mips64el|musl|glibc)(?:$|[-_/])/i;
const fields=['os','cpu','libc'];
const lockNames=['npm-shrinkwrap.json','package-lock.json','pnpm-lock.yaml'];
const archiveName=path=>/\.(?:tgz|tar\.gz|tar)$/.test(path);
const installManifest=path=>path==='package/package.json'||/\/node_modules\/(?:@[^/]+\/)?[^/]+\/package\.json$/.test(path);
function sourceKind(spec){
  if(typeof spec!=='string'||!spec) return 'unknown';
  if(spec.startsWith('npm:'))return 'registry';
  for(const type of ['file','link','workspace'])if(spec.startsWith(type+':'))return type;
  if(/^https?:/.test(spec))return 'tarball';
  if(/^(?:git(?:\+[^:]+)?:|github:|gitlab:|bitbucket:|ssh:)/.test(spec))return 'git';
  if(spec.startsWith('.')||spec.startsWith('/')||archiveName(spec))return 'file';
  if(/^(?:git(?:\+[^:]+)?:|github:|gitlab:|bitbucket:|ssh:|[^/@:]+\/[^/]+)/.test(spec))return 'git';
  if(semver.validRange(spec)||/^[a-zA-Z][a-zA-Z0-9._-]*$/.test(spec))return 'registry';
  return 'unknown';
}
const object=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
const own=(a,k)=>Object.hasOwn(a,k);
const digest=b=>createHash('sha256').update(b).digest('hex');
export class GateError extends Error {
  constructor(findings){super(INVARIANT);this.findings=findings;}
}
const fail=(code,pkg,path,detail)=>{throw new GateError([{code,package:pkg,path,detail}]);};
function unsupported(pkg,path,shape,why){
  const action='Use a shape in DEPENDENCY_SHAPES.md and regenerate the frozen lock with the normal package manager; otherwise request a reviewed contract extension before publishing. No bypass or inferred resolution.';
  throw new GateError([{code:'UNSUPPORTED_DEPENDENCY_SHAPE',package:pkg??'unknown',path,shape,why,action,contract:DEPENDENCY_SHAPE_CONTRACT.id,detail:shape+': '+why+' '+action}]);
}
function exactKeys(value,allowed,pkg,path,prefix){
  for(const key of Object.keys(value))if(!allowed.includes(key))unsupported(pkg,path+'/'+key,prefix+'.'+key,'this resolver field is outside the versioned lock grammar');
}
// Declaration admission is exhaustive. A recognized source is not permission
// to choose an arbitrary materialization; admitEdge makes that second decision.
function declarationShape(name,spec,path){
  if(typeof spec!=='string'||!spec)unsupported(name,path,'declaration.non-string-or-empty','an effective declaration must be a nonempty string');
  const kind=sourceKind(spec);
  if(kind==='registry'||kind==='git'){
    let parsed;try{parsed=npa.resolve(name,spec,'/__hanamesh_archive__');}catch{unsupported(name,path,'declaration.'+(kind==='registry'&&spec.startsWith('npm:')?'registry-alias':kind),'fixed npm-package-arg 13.0.2 cannot parse this declaration');}
    const admitted=kind==='git'?parsed.type==='git':['version','range','tag'].includes(parsed.type)||parsed.type==='alias'&&['version','range','tag'].includes(parsed.subSpec?.type);
    if(!admitted)unsupported(name,path,'declaration.'+kind,'parsed source type is outside the supported declaration whitelist');
  }
  switch(kind){
    case 'registry': {
      const t=target(name,spec);
      if(!(semver.validRange(t.range)||/^[a-zA-Z][a-zA-Z0-9._-]*$/.test(t.range)))unsupported(name,path,'declaration.registry','registry targets require a semver range or a literal dist-tag');
      return kind;
    }
    case 'workspace':
      if(!spec.slice(10).trim()||!['*','^','~'].includes(spec.slice(10))&&!semver.validRange(spec.slice(10)))unsupported(name,path,'declaration.workspace','only workspace:* / ^ / ~ / semver with an explicit frozen directory binding is supported');
      return kind;
    case 'file': case 'link':
      if(!spec.replace(/^(?:file|link):/,''))unsupported(name,path,'declaration.'+kind,'a concrete relative local target is required');
      if(posix.isAbsolute(spec.replace(/^(?:file|link):/,''))||spec.includes('\\'))unsupported(name,path,'declaration.local-target','only relative POSIX archive coordinates are modeled; absolute or backslash coordinates cannot bind this portable archive');
      return kind;
    case 'git': return kind; // Only an actual packed bundle can materialize it.
    case 'tarball': {
      if(!spec.startsWith('https:'))unsupported(name,path,'declaration.'+spec.split(':')[0],'only anonymous HTTPS remote artifacts are modeled');
      let url;try{url=new URL(spec);}catch{unsupported(name,path,'declaration.tarball','HTTPS declarations require a valid URL');}
      if(url.protocol!=='https:')unsupported(name,path,'declaration.tarball','HTTPS declarations require the HTTPS protocol');
      if(url.username||url.password||url.search||url.hash)unsupported(name,path,'declaration.tarball-url-policy','authenticated URLs and URLs with query/hash are outside the anonymous immutable HTTPS artifact contract, including packed bundles');
      return kind;
    }
    default:
      unsupported(name,path,'declaration.'+(spec.split(':')[0]||'unknown'),'source is outside the explicit registry/git/file/link/workspace/HTTPS declaration grammar');
  }
}
function manifestGrammar(pkg,path){
  if(!object(pkg))unsupported('unknown',path,'manifest.object','install metadata must be an object');
  const name=pkg.name??'unknown';
  for(const field of ['overrides','resolutions','pnpm','acceptDependencies','dependenciesMeta'])if(pkg[field]!==undefined)unsupported(name,path+'/'+field,'manifest.'+field,'resolution modifiers or peer acceptance overrides are not modeled by this contract');
  for(const field of ['dependencies','optionalDependencies','peerDependencies']){
    if(pkg[field]!==undefined&&!object(pkg[field]))unsupported(name,path+'/'+field,'manifest.'+field,'dependency declarations require a name-to-string map');
    for(const [dep,spec]of Object.entries(pkg[field]??{})){
      if(!/^(?:@[^/\s]+\/)?[^/\s]+$/.test(dep))unsupported(name,path+'/'+field+'/'+dep,'declaration.name','package names must be unambiguous npm names');
      if(typeof spec!=='string'||!spec)unsupported(dep,path+'/'+field+'/'+dep,'declaration.non-string-or-empty','declarations must be nonempty strings');
    }
  }
  // npm's spelling precedence does not make the other control field invisible.
  for(const field of ['bundleDependencies','bundledDependencies'])if(own(pkg,field)){
    const value=pkg[field];
    if(typeof value!=='boolean'&&(!Array.isArray(value)||value.some(x=>typeof x!=='string'||!x)))unsupported(name,path+'/'+field,'manifest.'+field,'each bundle spelling must independently be a boolean or nonempty-name array');
  }
  if(own(pkg,'workspaces')){
    const value=pkg.workspaces;
    if(object(value))exactKeys(value,['packages'],name,path+'/workspaces','manifest.workspaces');
    const patterns=Array.isArray(value)?value:object(value)?value.packages:null;
    if(!Array.isArray(patterns)||patterns.some(x=>typeof x!=='string'||!x))unsupported(name,path+'/workspaces','manifest.workspaces','workspaces require a pattern array or an object containing only a packages pattern array');
  }
  if(pkg.peerDependenciesMeta!==undefined){
    if(!object(pkg.peerDependenciesMeta))unsupported(name,path+'/peerDependenciesMeta','manifest.peerDependenciesMeta','expected a peer metadata map');
    for(const [dep,meta]of Object.entries(pkg.peerDependenciesMeta))if(!object(meta)||Object.keys(meta).some(k=>k!=='optional')||meta.optional!==undefined&&typeof meta.optional!=='boolean')unsupported(dep,path+'/peerDependenciesMeta/'+dep,'manifest.peerDependenciesMeta','only boolean optional is modeled');
  }
}
function manifestShape(pkg,path,shadowed=new Map(),graphRoot=false){
  manifestGrammar(pkg,path);
  for(const field of ['dependencies','optionalDependencies','peerDependencies'])for(const [name,spec]of Object.entries(pkg[field]??{})){
    if(graphRoot&&shadowed.has(name))continue; // Replaced npm root edge, not an effective declaration.
    declarationShape(name,spec,path+'/'+field+'/'+name);
  }
}
const NPM_RECORD_KEYS=['name','version','resolved','integrity','dev','devOptional','optional','peer','inBundle','dependencies','optionalDependencies','peerDependencies','peerDependenciesMeta','devDependencies','bin','engines','license','hasInstallScript','hasShrinkwrap','os','cpu','libc','deprecated','funding','bundleDependencies','bundledDependencies','workspaces',
  'private','main','type','files','scripts','description','exports','types','typings','repository','author','contributors','keywords','homepage','bugs','publishConfig','packageManager'];
function typedFields(data,stringFields,booleanFields,name,path,prefix){
  for(const field of stringFields)if(data[field]!==undefined&&typeof data[field]!=='string')unsupported(name,path+'/'+field,prefix+'.'+field,'this admitted field requires a string value');
  for(const field of booleanFields)if(data[field]!==undefined&&typeof data[field]!=='boolean')unsupported(name,path+'/'+field,prefix+'.'+field,'this admitted field requires a boolean value');
}
function npmRecord(data,name,path){
  manifestGrammar(data,path);
  exactKeys(data,NPM_RECORD_KEYS,name,path,'lock.npm.record');
  typedFields(data,['name','version','resolved','integrity'],['dev','devOptional','optional','peer','inBundle','hasInstallScript','hasShrinkwrap'],name,path,'lock.npm.record');
}
function target(name,spec){
  if(typeof spec==='string'&&spec.startsWith('npm:')){
    const path='dependency/'+name;
    let parsed;try{parsed=npa.resolve(name,spec,'/__hanamesh_archive__');}catch{unsupported(name,path,'declaration.registry-alias','fixed npm-package-arg 13.0.2 cannot parse this alias');}
    if(parsed.type!=='alias'||!['version','range','tag'].includes(parsed.subSpec?.type))unsupported(name,path,'declaration.registry-alias','only npm aliases to registry version/range/tag targets are modeled');
    // fetchSpec is npm's exact normalization, including whitespace-only ranges.
    // Do not replace its empty string with '*': npm distinguishes these ranges.
    return {name:parsed.subSpec.name,range:parsed.subSpec.fetchSpec};
  }
  return {name,range:spec};
}
function inspect(pkg,path,findings,shadowed=new Map()){
  if(!object(pkg))fail('EVIDENCE_INVALID','unknown',path,'package metadata must be an object');
  for(const field of fields)if(own(pkg,field))findings.push({code:'PLATFORM_FIELD',package:pkg.name??'unknown',path:path+'/'+field,detail:`${field} present: ${JSON.stringify(pkg[field])}`});
  if(pkg.optionalDependencies!==undefined&&!object(pkg.optionalDependencies))fail('EVIDENCE_INVALID',pkg.name,path+'/optionalDependencies','expected dependency map');
  for(const [name,spec] of Object.entries(pkg.optionalDependencies??{}))if(!shadowed.has(name)&&(PLATFORM_TOKEN.test(name)||PLATFORM_TOKEN.test(target(name,spec).name)))findings.push({code:'PLATFORM_OPTIONAL',package:pkg.name??'unknown',path:path+'/optionalDependencies/'+name,detail:`platform subpackage reference ${name}: ${spec}`});
}
function deps(pkg){
  for(const field of ['dependencies','optionalDependencies','peerDependencies'])if(pkg[field]!==undefined&&!object(pkg[field]))fail('EVIDENCE_INVALID',pkg.name,'manifest/'+field,'expected dependency map');
  return {...pkg.dependencies,...pkg.optionalDependencies};
}
function peerDeclarations(pkg,path){
  if(pkg.peerDependencies!==undefined&&!object(pkg.peerDependencies))fail('EVIDENCE_INVALID',pkg.name,path+'/peerDependencies','expected peer dependency map');
  if(pkg.peerDependenciesMeta!==undefined&&!object(pkg.peerDependenciesMeta))fail('EVIDENCE_INVALID',pkg.name,path+'/peerDependenciesMeta','expected peer metadata map');
  return Object.entries(pkg.peerDependencies??{}).map(([name,spec])=>{
    if(typeof spec!=='string')fail('EVIDENCE_INVALID',pkg.name,path+'/peerDependencies/'+name,'expected peer dependency spec');
    return {name,spec,optional:pkg.peerDependenciesMeta?.[name]?.optional===true,path:path+'/peerDependencies/'+name};
  });
}
function bundles(pkg){
  const value=pkg.bundleDependencies??pkg.bundledDependencies??[];
  if(value===true)return Object.keys(deps(pkg));
  if(value===false)return [];
  if(!Array.isArray(value)||value.some(x=>typeof x!=='string'))fail('EVIDENCE_INVALID',pkg.name,'manifest/bundleDependencies','expected boolean or name array');
  return value;
}
async function manifests(buffer,label){
  const result=new Map();
  result.archives=new Map();result.locks=new Map();
  await new Promise((ok,no)=>{
    const parser=new Parser({strict:true,onReadEntry(entry){
      const path=entry.path.replace(/^\.\//,'');
      if(posix.isAbsolute(path)||path.split('/').includes('..')){no(new GateError([{code:'ARCHIVE_INVALID',package:'unknown',path:label,detail:'unsafe archive path'}]));entry.resume();return;}
      const wanted=path.startsWith('package/')&&posix.basename(path)==='package.json';
      const locked=path.startsWith('package/')&&lockNames.includes(posix.basename(path));
      const archive=archiveName(path);
      if(!wanted&&!archive&&!locked){entry.resume();return;}
      if(entry.type!=='File'&&entry.type!=='OldFile'){no(new GateError([{code:'ARCHIVE_INVALID',package:'unknown',path:label+'!'+path,detail:'required manifest, lock or archive entry must be a regular file'}]));entry.resume();return;}
      const store=archive?result.archives:locked?result.locks:result;
      if(store.has(path)){no(new GateError([{code:'ARCHIVE_INVALID',package:'unknown',path:label+'!'+path,detail:'duplicate archive entry'}]));entry.resume();return;}
      store.set(path,null);const chunks=[];
      entry.on('data',b=>chunks.push(b));entry.on('end',()=>{
        const bytes=Buffer.concat(chunks);
        if(archive||locked){store.set(path,bytes);return;}
        try{const pkg=JSON.parse(bytes.toString());if(!object(pkg)||(installManifest(path)&&(typeof pkg.name!=='string'||typeof pkg.version!=='string')))throw Error();result.set(path,pkg);}
        catch{no(new GateError([{code:'ARCHIVE_INVALID',package:'unknown',path:label+'!'+path,detail:'invalid package JSON/name/version'}]));}
      });
    }});
    parser.on('error',()=>no(new GateError([{code:'ARCHIVE_INVALID',package:'unknown',path:label,detail:'invalid tar archive'}])));
    parser.on('end',ok);parser.end(buffer);
  });
  if(!result.get('package/package.json'))fail('ARCHIVE_INVALID','unknown',label,'package/package.json missing');
  return result;
}
function parseLock(text,path){
  let lock;try{lock=path.endsWith('.json')?JSON.parse(text):YAML.parse(text,{uniqueKeys:true});}catch{fail('LOCK_INVALID','unknown',path,'invalid JSON/YAML');}
  if(!object(lock))fail('LOCK_INVALID','unknown',path,'lock object required');
  if(!path.endsWith('.json')&&String(lock.lockfileVersion)==='9.0'&&lock.packages===undefined&&lock.snapshots===undefined){lock.packages={};lock.snapshots={};}
  if(path.endsWith('.json')){
    if(![2,3].includes(lock.lockfileVersion))unsupported('unknown',path,'lock.npm.version','requires numeric npm lockfileVersion 2 or 3 with an authoritative packages table');
    if(!object(lock.packages))fail('LOCK_INVALID','unknown',path,'packages required');
    if(!object(lock.packages['']))fail('LOCK_INVALID','unknown',path,'npm root package record required');
    exactKeys(lock,['name','version','lockfileVersion','requires','packages','dependencies'],'unknown',path,'lock.npm');
    const map=lock.packages;
    npmRecord(map[''],map[''].name??'unknown',path+'#packages/');
    return {format:'npm',root:map[''],workspaceRecords:map,rootRef(name){return lookup('',name);},get:key=>map[key],
      bundleRef(base,relative){const key=posix.normalize(posix.join(base,relative));return own(map,key)?key:null;},
      node(key){
        let data=map[key],targetKey=key;
        if(!data)fail('CLOSURE_UNPROVEN',key,path+'#packages/'+key,'missing npm record');
        if(own(data,'link')&&data.link!==true)unsupported(key,path+'#packages/'+key,'lock.npm.link-payload','link must be literal true');
        if(data.link){
          typedFields(data,['resolved'],['dev','optional','devOptional'],key,path+'#packages/'+key,'lock.npm.link-payload');
          if(Object.keys(data).some(k=>!['link','resolved','dev','optional','devOptional'].includes(k)))unsupported(key,path+'#packages/'+key,'lock.npm.link-payload','link records must contain only their concrete target and install classification flags');
          targetKey=data.resolved;
          if(typeof targetKey!=='string'||posix.isAbsolute(targetKey)||targetKey.split('/').includes('..')||!object(map[targetKey])||map[targetKey].link)fail('CLOSURE_UNPROVEN',key,path+'#packages/'+key,'linked npm target must be a concrete record within the lock');
          data=map[targetKey];
        }
        npmRecord(data,data?.name??key,path+'#packages/'+targetKey);
        manifestShape(data,path+'#packages/'+targetKey);
        return {key,targetKey,linked:targetKey!==key,identityName:data.name??null,meta:{name:data.name??key.split('node_modules/').at(-1),...data},edges:{...data.dependencies,...data.optionalDependencies},peers:peerDeclarations(data,path+'#packages/'+targetKey),optional:data.optionalDependencies??{},ref:name=>lookup(targetKey,name),resolution:{tarball:data.resolved,integrity:data.integrity}};
      }};
    function lookup(key,name){for(let at=key;;){const candidate=(at?at+'/':'')+'node_modules/'+name;if(own(map,candidate))return candidate;if(!at)return null;const i=at.lastIndexOf('/node_modules/');at=i<0?'':at.slice(0,i);}}
  }
  if(String(lock.lockfileVersion)!=='9.0')unsupported('unknown',path,'lock.pnpm.version','requires pnpm lockfileVersion 9.0');
  if(!object(lock.packages))fail('LOCK_INVALID','unknown',path,'packages required');
  exactKeys(lock,['lockfileVersion','settings','importers','packages','snapshots'],'unknown',path,'lock.pnpm');
  if(lock.settings!==undefined){
    if(!object(lock.settings))unsupported('unknown',path+'/settings','lock.pnpm.settings','settings must be a map');
    exactKeys(lock.settings,['autoInstallPeers','excludeLinksFromLockfile'],'unknown',path+'/settings','lock.pnpm.settings');
    if(lock.settings.autoInstallPeers!==undefined&&lock.settings.autoInstallPeers!==true||lock.settings.excludeLinksFromLockfile!==undefined&&lock.settings.excludeLinksFromLockfile!==false)unsupported('unknown',path+'/settings','lock.pnpm.settings-values','supported frozen settings are autoInstallPeers=true and excludeLinksFromLockfile=false');
  }
  if(!object(lock.importers?.['.'])||!object(lock.snapshots))fail('LOCK_INVALID','unknown',path,'requires root importer and snapshots');
  const root=lock.importers['.'];
  for(const [key,importer]of Object.entries(lock.importers)){
    if(!object(importer))unsupported('unknown',path+'#importers/'+key,'lock.pnpm.importer','importers must be maps');
    exactKeys(importer,['dependencies','optionalDependencies','devDependencies','peerDependencies','peerDependenciesMeta'],'unknown',path+'#importers/'+key,'lock.pnpm.importer');
    manifestShape({name:'importer:'+key,peerDependencies:importer.peerDependencies,peerDependenciesMeta:importer.peerDependenciesMeta},path+'#importers/'+key);
    for(const field of ['dependencies','optionalDependencies','devDependencies']){
      if(importer[field]!==undefined&&!object(importer[field]))unsupported('unknown',path+'#importers/'+key+'/'+field,'lock.pnpm.importer-edge','import dependencies must be maps');
      for(const [name,edge]of Object.entries(importer[field]??{})){
      if(!object(edge)||typeof edge.specifier!=='string'||typeof edge.version!=='string')unsupported(name,path+'#importers/'+key+'/'+field+'/'+name,'lock.pnpm.importer-edge','effective import edges require string specifier and version');
      exactKeys(edge,['specifier','version'],name,path+'#importers/'+key+'/'+field+'/'+name,'lock.pnpm.importer-edge');
    }}
  }
  const localNodes=new Map();
  function lookup(name,ref,owner='.'){
    if(typeof ref!=='string')return null;
    if(ref.startsWith('link:')){
      const relative=ref.slice(5),directory=posix.normalize(posix.join(owner,relative));
      if(posix.isAbsolute(relative)||directory==='..'||directory.startsWith('../')||relative.includes('\\'))return null;
      const importer=lock.importers[directory]??{};
      if(!object(importer))return null;
      const key='link:'+directory+'#'+name;
      localNodes.set(key,{name,directory,importer});return key;
    }
    const choices=ref.startsWith('npm:')?[ref.slice(4)]:[name+'@'+ref,ref];
    return choices.find(key=>own(lock.snapshots,key))??null;
  }
  function peerContext(key){
    const result=new Map();let at=key.indexOf('(');
    while(at!==-1&&at<key.length){
      if(key[at]!=='(')fail('LOCK_INVALID','unknown',path+'#snapshots/'+key,'invalid peer context');
      let depth=1,end=at+1;
      for(;end<key.length&&depth;end++){if(key[end]==='(')depth++;else if(key[end]===')')depth--;}
      if(depth)fail('LOCK_INVALID','unknown',path+'#snapshots/'+key,'unbalanced peer context');
      const ref=key.slice(at+1,end-1),base=ref.split('(')[0],split=base.indexOf('@',1);
      if(split<1)unsupported('unknown',path+'#snapshots/'+key,'lock.pnpm.peer-context','context must contain an explicit peer name and locked reference');
      const name=base.slice(0,split);
      if(result.has(name)&&result.get(name)!==ref)fail('LOCK_INVALID',name,path+'#snapshots/'+key,'contradictory peer bindings');
      result.set(name,ref);at=end;
    }
    return result;
  }
  return {format:'pnpm',root,rootRef(name){const ref=root.dependencies?.[name]??root.optionalDependencies?.[name]??root.devDependencies?.[name];return lookup(name,ref?.version);},
    get:key=>lock.packages[key?.split('(')[0]],node(key){
      if(localNodes.has(key)){
        const {name,directory,importer}=localNodes.get(key);
        const edgeMap=entries=>Object.fromEntries(Object.entries(entries??{}).map(([n,v])=>[n,v.specifier]));
        return {key,targetKey:directory,linked:true,identityName:name,meta:{name},edges:{...edgeMap(importer.dependencies),...edgeMap(importer.optionalDependencies)},peers:peerDeclarations(importer,path+'#importers/'+directory),optional:edgeMap(importer.optionalDependencies),ref:n=>lookup(n,(importer.optionalDependencies?.[n]??importer.dependencies?.[n]??importer.devDependencies?.[n])?.version,directory),resolution:{}};
      }
      const snapshot=lock.snapshots[key],base=key.split('(')[0],meta=lock.packages[base];
      if(!object(snapshot)||!object(meta))fail('CLOSURE_UNPROVEN',key,path+'#snapshots/'+key,'missing snapshot/package metadata');
      exactKeys(meta,['resolution','name','version','id','engines','cpu','os','libc','hasBin','deprecated','peerDependencies','peerDependenciesMeta','bundledDependencies','bundleDependencies','requiresBuild','optional','dev'],key,path+'#packages/'+base,'lock.pnpm.record');
      exactKeys(snapshot,['dependencies','optionalDependencies','optional','transitivePeerDependencies','peerDependencies','peerDependenciesMeta','id'],key,path+'#snapshots/'+key,'lock.pnpm.snapshot');
      if(meta.resolution!==undefined){
        if(!object(meta.resolution))unsupported(key,path+'#packages/'+base+'/resolution','lock.pnpm.resolution','resolution must be a map');
        exactKeys(meta.resolution,['integrity','tarball'],key,path+'#packages/'+base+'/resolution','lock.pnpm.resolution');
        typedFields(meta.resolution,['integrity','tarball'],[],key,path+'#packages/'+base+'/resolution','lock.pnpm.resolution');
      }
      for(const field of ['dependencies','optionalDependencies']){
        if(snapshot[field]!==undefined&&!object(snapshot[field]))unsupported(key,path+'#snapshots/'+key+'/'+field,'lock.pnpm.snapshot-edge','snapshot dependencies must be name-to-reference maps');
        for(const [name,ref]of Object.entries(snapshot[field]??{}))if(typeof ref!=='string'||!ref)unsupported(name,path+'#snapshots/'+key+'/'+field+'/'+name,'lock.pnpm.snapshot-edge','snapshot references must be nonempty strings');
      }
      typedFields(meta,['name','version','id'],['hasBin','requiresBuild','optional','dev'],key,path+'#packages/'+base,'lock.pnpm.record');
      typedFields(snapshot,['id'],['optional'],key,path+'#snapshots/'+key,'lock.pnpm.snapshot');
      if(snapshot.transitivePeerDependencies!==undefined&&(!Array.isArray(snapshot.transitivePeerDependencies)||snapshot.transitivePeerDependencies.some(x=>typeof x!=='string')))unsupported(key,path+'#snapshots/'+key+'/transitivePeerDependencies','lock.pnpm.snapshot.transitivePeerDependencies','transitive peer descriptors must be a string array');
      manifestShape(meta,path+'#packages/'+base);
      manifestShape({peerDependencies:snapshot.peerDependencies,peerDependenciesMeta:snapshot.peerDependenciesMeta},path+'#snapshots/'+key);
      const split=base.indexOf('@',1);const name=base.slice(0,split),version=base.slice(split+1);
      const boundPeers=peerContext(key);
      // A snapshot context is itself a frozen resolved peer edge. Its target
      // cannot be reclassified as an absent optional peer when metadata drifts.
      const bindings=[...boundPeers].map(([name,ref])=>{
        // pnpm shortens cyclic peer contexts; the same snapshot's dependency
        // retains the complete frozen target. A missing explicit target stays missing.
        const target=lookup(name,snapshot.optionalDependencies?.[name]??snapshot.dependencies?.[name]??ref),peerPath=path+'#snapshots/'+key+'/peer-context/'+name;
        if(target&&target.split('(')[0]!==ref.split('(')[0])fail('LOCK_DRIFT',name,peerPath,'frozen snapshot dependency differs from peer context name@version');
        return {name,spec:ref.split('(')[0].slice(name.length+1),optional:false,resolved:true,key:target,path:peerPath};
      });
      const peers=[...bindings,...peerDeclarations(meta,path+'#packages/'+base),...peerDeclarations(snapshot,path+'#snapshots/'+key)];
      return {key,identityName:name,meta:{name,...(semver.valid(version)?{version}:{}),...meta},edges:{...snapshot.dependencies,...snapshot.optionalDependencies},peers,optional:snapshot.optionalDependencies??{},ref:name=>lookup(name,snapshot.optionalDependencies?.[name]??snapshot.dependencies?.[name]??boundPeers.get(name)),resolution:meta.resolution};
    }};
}
function sri(buffer,integrity,name,path){
  if(typeof integrity!=='string')fail('CLOSURE_UNPROVEN',name,path,'locked integrity required');
  const tokens=integrity.split(/\s+/);const strongest=['sha512','sha384','sha256'].find(a=>tokens.some(s=>s.startsWith(a+'-')));
  if(!strongest)fail('CLOSURE_UNPROVEN',name,path,'strong SHA256/384/512 integrity required');
  const expected=createHash(strongest).update(buffer).digest('base64');
  if(!tokens.some(x=>x===strongest+'-'+expected))fail('INTEGRITY_MISMATCH',name,path,'locked artifact digest mismatch; no fallback');
}

export async function checkRelease({tarball,lockfile,sourceRoot,artifactCache}={}){
  if(typeof tarball!=='string'||typeof lockfile!=='string')fail('ARGUMENT_INVALID','release','arguments','tarball and lockfile required');
  tarball=resolve(tarball);lockfile=resolve(lockfile);sourceRoot=resolve(sourceRoot??dirname(lockfile));
  const rootBuffer=await readFile(tarball),packed=await manifests(rootBuffer,tarball),root=packed.get('package/package.json');
  const findings=[];for(const [path,pkg] of packed)if(installManifest(path))inspect({...pkg,optionalDependencies:undefined},tarball+'!'+path,findings);
  if(findings.length)throw new GateError(findings);
  const visited=new Set(),checked=[],checkedLocks=[],sourceEdges=[],absentOptionalPeers=[],absentPeerIds=new Map(),selfContainedBundles=[],ownLocksVisited=new Set();let fetched=0;
  async function scan(packed,rootLabel,lock,lockfile,rootLocksScanned=false,rootPath='package/package.json'){
    const metadataInspected=new Set(),root=packed.get(rootPath);
    manifestGrammar(root,rootLabel+'!'+rootPath);
    const rootDeps=deps(root),rootPeers=peerDeclarations(lock.root,lockfile+'#root');
    checkedLocks.push({path:lockfile,format:lock.format});
    inspect({name:root.name,...lock.root,optionalDependencies:undefined},lockfile+'#root',findings);
    if(findings.length)throw new GateError(findings);
    if(lock.format==='npm'&&(lock.root.name!==root.name||lock.root.version!==root.version))fail('LOCK_DRIFT',root.name,lockfile+'#packages/','lock root identity differs from packed release');
    for(const name of Object.keys({...lock.root.dependencies,...lock.root.optionalDependencies}))if(!own(rootDeps,name)&&!own(root.peerDependencies??{},name)&&!rootPeers.some(p=>p.name===name))fail('LOCK_DRIFT',root.name,lockfile+'#importer/'+name,'frozen root production edge is absent from packed release');
    for(const [name,spec] of Object.entries(rootDeps)){
      const got=lock.root.optionalDependencies?.[name]??lock.root.dependencies?.[name];
      if((lock.format==='pnpm'?got?.specifier:got)!==spec)fail('LOCK_DRIFT',root.name,lockfile+'#importer/'+name,'packed dependency spec differs from frozen root importer');
    }
    // npm creates root workspace edges before production/optional/peer edges.
    // Resolve them from actual archive manifests with npm's own virtual matcher,
    // never from the source tree or by repeatedly URI-decoding file names.
    const workspaces=new Map(),graphRoot=posix.dirname(rootPath);
    if(lock.format==='npm'){
      const declaration=value=>value===undefined?[]:Array.isArray(value?.packages)?value.packages:value;
      if(!isDeepStrictEqual(declaration(root.workspaces),declaration(lock.root.workspaces)))fail('LOCK_DRIFT',root.name,lockfile+'#root/workspaces','packed workspaces differ from frozen root');
      if(root.workspaces!==undefined){
        const cwd=resolve('/__hanamesh_archive__'),packages=Object.create(null);packages['']={workspaces:root.workspaces};
        for(const key of Object.keys(lock.workspaceRecords))if(key)packages[key]={name:key};
        for(const [path,pkg]of packed){
          if(path===rootPath||!path.startsWith(graphRoot+'/')||typeof pkg.name!=='string'||typeof pkg.version!=='string')continue;
          const key=posix.relative(graphRoot,posix.dirname(path));
          // Unique temporary names keep every matched path visible, so duplicate
          // actual names cannot be hidden by virtual()'s name-keyed return map.
          packages[key]={name:key};
        }
        let matches;try{matches=mapWorkspaces.virtual({cwd,lockfile:{packages}});}catch{unsupported(root.name,rootLabel+'!'+rootPath+'/workspaces','manifest.workspaces-pattern','fixed npm workspace matcher 5.0.3 cannot resolve these patterns within the finite archive model');}
        for(const path of matches.values()){
          const key=relative(cwd,path).split(sep).join('/'),physical=posix.join(graphRoot,key),pkg=packed.get(physical+'/package.json');
          if(posix.isAbsolute(key)||key.split('/').includes('..')||key.includes('\\'))fail('CLOSURE_UNPROVEN',lock.workspaceRecords[key]?.name??root.name,rootLabel+'!'+rootPath+'/workspaces','workspace target is not a relative directory inside its frozen graph');
          if(!pkg||physical!=='package'&&!physical.startsWith('package/'))fail('CLOSURE_UNPROVEN',lock.workspaceRecords[key]?.name??key,rootLabel+'!'+rootPath+'/workspaces','workspace directory missing from actual archive or outside its boundary');
          if(typeof pkg.name!=='string'||typeof pkg.version!=='string')fail('EVIDENCE_INVALID',root.name,rootLabel+'!'+physical+'/package.json','actual npm workspace name/version required');
          if(workspaces.has(pkg.name)&&workspaces.get(pkg.name)!==physical)fail('WORKSPACE_AMBIGUOUS',pkg.name,rootLabel+'!'+rootPath+'/workspaces','multiple actual workspace directories share a package name');
          workspaces.set(pkg.name,physical);
        }
      }
    }
    manifestShape(root,rootLabel+'!'+rootPath,workspaces,true);
    if(lock.format==='npm')manifestShape(lock.root,lockfile+'#root',workspaces,true);
    inspect({name:root.name,...lock.root},lockfile+'#root',findings,workspaces);
    if(findings.length)throw new GateError(findings);
    function findBundle(context,manifestPath,name){
      let dir=posix.dirname(manifestPath);
      for(;;){const candidate=dir+'/node_modules/'+name+'/package.json';if(context.map.has(candidate))return candidate;if(dir==='package')return null;dir=posix.dirname(dir);if(dir==='.'||dir==='/')return null;}
    }
    async function bytes(node){
      let location=node.resolution?.tarball;
      if(!location&&semver.valid(node.meta.version)&&!node.meta.version.includes(':'))location=`https://registry.npmjs.org/${node.meta.name}/-/${node.meta.name.split('/').at(-1)}-${node.meta.version}.tgz`;
      if(typeof location!=='string')fail('CLOSURE_UNPROVEN',node.meta.name,lockfile+'#'+node.key,'locked tarball location required');
      // Location policy is checked before using cache, not just before a GET.
      if(!location.startsWith('file:')){
        let url;try{url=new URL(location);}catch{unsupported(node.meta.name,lockfile+'#'+node.key,'resolution.artifact','fixed artifact location cannot be parsed as a URL');}
        if(url.protocol!=='https:')unsupported(node.meta.name,lockfile+'#'+node.key,'resolution.'+url.protocol.slice(0,-1),'only local locked tar or HTTPS artifacts are modeled');
          if(url.username||url.password||url.search||url.hash)unsupported(node.meta.name,lockfile+'#'+node.key,'resolution.https-policy','authenticated URLs and URLs with query/hash are outside the anonymous immutable HTTPS artifact contract');
      }
      const cache=artifactCache?resolve(artifactCache,digest(Buffer.from(node.resolution.integrity??''))+'.tgz'):null;
      let buffer;
      if(cache){try{buffer=await readFile(cache);}catch(e){if(e.code!=='ENOENT')throw e;}}
      if(!buffer){
        if(location.startsWith('file:')){
          const path=resolve(sourceRoot,location.slice(5));if(!archiveName(path))unsupported(node.meta.name,lockfile+'#'+node.key,'resolution.local-artifact','frozen file artifact locations must explicitly name a .tgz/.tar.gz/.tar; directory supply requires a concrete admitted link binding');buffer=await readFile(path);
        }else{
          let url;try{url=new URL(location);}catch{unsupported(node.meta.name,lockfile+'#'+node.key,'resolution.artifact','fixed artifact location cannot be parsed as a URL');}
          if(url.protocol!=='https:')unsupported(node.meta.name,lockfile+'#'+node.key,'resolution.'+url.protocol.slice(0,-1),'only local locked tar or HTTPS artifacts are modeled');
          if(url.username||url.password||url.search||url.hash)unsupported(node.meta.name,lockfile+'#'+node.key,'resolution.https-policy','authenticated URLs and URLs with query/hash are outside the anonymous immutable HTTPS artifact contract');
          const response=await fetch(url,{redirect:'error'});if(!response.ok)fail('ARTIFACT_UNAVAILABLE',node.meta.name,lockfile+'#'+node.key,'artifact GET status '+response.status);
          buffer=Buffer.from(await response.arrayBuffer());fetched++;
        }
        sri(buffer,node.resolution.integrity,node.meta.name,lockfile+'#'+node.key);
        if(cache){await mkdir(dirname(cache),{recursive:true});await writeFile(cache,buffer,{flag:'wx'});}
      }else sri(buffer,node.resolution.integrity,node.meta.name,lockfile+'#'+node.key);
      return buffer;
    }
    function inspectNode(node){
      function collect(current){
        if(metadataInspected.has(current.key))return;metadataInspected.add(current.key);
        inspect(current.meta,lockfile+'#packages/'+current.key,findings);
        inspect({...current.meta,optionalDependencies:current.optional},lockfile+'#snapshots/'+current.key,findings);
        for(const name of Object.keys(current.edges)){const key=current.ref(name);if(key)collect(lock.node(key));}
        for(const peer of current.peers){const key=peer.resolved?peer.key:current.ref(peer.name);if(peer.resolved&&!key)fail('CLOSURE_UNPROVEN',peer.name,peer.path,'explicit frozen peer binding has no resolved snapshot');if(key){const next=lock.node(key);incoming(next,null,peer.name,peer.spec,peer.path);collect(next);}}
      }
      collect(node);
      if(findings.length)throw new GateError(findings);
    }
    function incoming(node,pkg,name,spec,from){
      const expected=target(name,spec);
      if(expected.range?.startsWith('workspace:'))expected.range=expected.range.slice(10);
      if(node?.identityName&&node.identityName!==expected.name)fail('LOCK_DRIFT',name,from,'frozen package name differs from incoming dependency target');
      if(pkg&&pkg.name!==expected.name)fail('LOCK_DRIFT',name,from,'actual package name differs from dependency target '+expected.name);
      if(node&&pkg&&node.meta.version!==undefined&&pkg.version!==node.meta.version)fail('LOCK_DRIFT',name,from,'actual and locked versions differ');
      for(const version of [node?.meta.version,pkg?.version].filter(x=>x!==undefined)){
        // Match npm Arborist dep-valid: literal '*' accepts an already bound
        // version; other ranges use loose parsing with default prerelease exclusion.
        // Do not normalize x/>=0.0.0 to '*': npm does not give them that exception.
        if(semver.validRange(expected.range)&&(!semver.valid(version)||expected.range.trim()!=='*'&&!semver.satisfies(version,expected.range,true)))fail('LOCK_DRIFT',name,from,'version does not satisfy incoming dependency range');
      }
    }
    // Physical npm paths are authoritative for bundles/extras. pnpm has no
    // physical tree: use the nearest containing package's snapshot, never root fallback.
    function bundleKey(context,path){
      if(lock.format==='npm')return lock.bundleRef(context.baseNode?.targetKey??context.baseNode?.key??'',posix.relative(context.packageRoot,posix.dirname(path)));
      const dir=path.slice(0,-'/package.json'.length),at=dir.lastIndexOf('/node_modules/');
      const parent=dir.slice(0,at)+'/package.json',name=dir.slice(at+'/node_modules/'.length);
      const owner=context.bindings.get(parent);
      if(owner)return owner.ref(name);
      return parent===rootPath&&!context.baseNode?lock.rootRef(name):null;
    }
    // Directory packages retain their original physical archive coordinates. A new
    // graph root belongs to an own lock, not to a cropped/rebased archive view.
    async function ownLocks(context,path){
      if(context.rootLocksScanned&&path===rootPath)return;
      const directory=posix.dirname(path);
      for(const name of lockNames){
        const key=directory+'/'+name,bytes=context.map.locks.get(key),label=context.label+'!'+key;
        if(!bytes||ownLocksVisited.has(label))continue;
        ownLocksVisited.add(label);
        await scan(context.map,context.label,parseLock(bytes.toString(),label),label,true,path);
      }
    }
    function packedLocal(context,path,name,spec,node){
      const kind=sourceKind(spec);
      if(!['file','link','workspace'].includes(kind))return null;
      let relative=kind==='workspace'?node?.targetKey:spec.replace(/^(?:file|link):/,'');
      // workspace's frozen link target is relative to the graph root, not the current package.
      const owner=kind==='workspace'?context.graphRoot:posix.dirname(path);
      if(typeof relative!=='string'||!relative||posix.isAbsolute(relative)||relative.includes('\\'))fail('CLOSURE_UNPROVEN',name,context.label+'!'+path,'local '+kind+' source must have a frozen relative target in the actual archive');
      const file=posix.normalize(posix.join(owner,relative));
      if(file!=='package'&&!file.startsWith('package/'))fail('CLOSURE_UNPROVEN',name,context.label+'!'+path,'local source escapes the actual archive');
      if(context.map.archives.has(file)&&(node?.linked||kind!=='file'))unsupported(name,context.label+'!'+file,'materialization.'+(node?.linked?'linked-archive':kind+'-archive'),'a concrete directory/link plan cannot consume an archive as a directory');
      if(kind==='file'&&archiveName(file)&&!node?.linked){
        const buffer=context.map.archives.get(file);
        if(!buffer)fail('CLOSURE_UNPROVEN',name,context.label+'!'+file,'referenced vendor archive missing from actual packed artifact; source tree is not a substitute');
        return {buffer,label:context.label+'!'+file};
      }
      if(!node?.linked)fail('CLOSURE_UNPROVEN',name,context.label+'!'+file,'local directory requires a concrete frozen link/importer binding; registry metadata is not a directory binding');
      if(file!==posix.normalize(posix.join(context.graphRoot,node.targetKey)))fail('LOCK_DRIFT',name,context.label+'!'+file,'actual directory path differs from frozen link/importer target');
      if(!context.map.has(file+'/package.json'))fail('CLOSURE_UNPROVEN',name,context.label+'!'+file,'local directory package missing from actual packed archive');
      return {map:context.map,label:context.label,path:file+'/package.json',graphRoot:context.graphRoot};
    }
    // Every effective edge needs one explicit admitted plan before traversal.
    // There is no default artifact/registry reconstruction branch.
    function admitEdge(context,path,name,spec,key,from,physicalBundle=null){
      const node=key?lock.node(key):null;
      if(!physicalBundle&&!context.node&&path===rootPath&&workspaces.has(name)){
        const physical=workspaces.get(name);
        if(!node?.linked)fail('CLOSURE_UNPROVEN',name,from,'npm workspace requires a concrete frozen link target');
        if(physical!==posix.normalize(posix.join(context.graphRoot,node.targetKey)))fail('LOCK_DRIFT',name,from,'actual npm workspace differs from frozen link target');
        return {strategy:'npm-root-workspace',kind:'workspace',effectiveSpec:'workspace:*',physical,embedded:{map:context.map,label:context.label,path:physical+'/package.json',graphRoot:context.graphRoot}};
      }
      const kind=declarationShape(name,spec,from),bundled=physicalBundle??findBundle(context,path,name);
      if(kind==='tarball'){
        if(!node||node.resolution?.tarball===undefined)fail('CLOSURE_UNPROVEN',name,from,'HTTPS declaration requires its explicit frozen artifact binding');
        if(node.resolution.tarball!==spec)fail('LOCK_DRIFT',name,from,'tarball URL differs from frozen artifact location, including packed bundles');
      }
      if(bundled){
        if(!context.map.has(bundled)||!installManifest(bundled))unsupported(name,from,'materialization.packed-bundle','bundle must be an actual install manifest in this archive');
        return {strategy:physicalBundle?'packed-bundle-extra':'packed-bundle',kind,effectiveSpec:spec,bundled,physical:posix.dirname(bundled)};
      }
      switch(kind){
        case 'git':
          unsupported(name,from,'declaration.git-unmaterialized','git checkout/prepare and registry substitution are not modeled; the actual git dependency must already be fully materialized in the packed bundle');
          break;
        case 'file': case 'link': case 'workspace': {
          const embedded=packedLocal(context,path,name,spec,node);
          if(!embedded)unsupported(name,from,'materialization.'+kind,'no admitted packed local materialization');
          return {strategy:'packed-'+kind,kind,effectiveSpec:spec,embedded};
        }
        case 'registry':
          if(node?.linked){
            // The true child range remains spec. Only its physical supplier is
            // taken from the concrete frozen link/importer, never from registry.
            const embedded=packedLocal(context,path,name,'workspace:*',node);
            return {strategy:'frozen-linked-directory',kind,effectiveSpec:spec,physical:posix.dirname(embedded.path),embedded};
          }
          if(lockfile.includes('!')&&sourceKind(node?.resolution?.tarball)==='file')return {strategy:'packed-file',kind,effectiveSpec:spec,embedded:packedLocal(context,path,name,node.resolution.tarball,node)};
          admitArtifact(node,name,from);
          return {strategy:'locked-registry-artifact',kind,effectiveSpec:spec};
        case 'tarball':
          if(node?.resolution?.tarball!==spec)fail('LOCK_DRIFT',name,from,'tarball URL differs from frozen artifact location');
          admitArtifact(node,name,from);
          return {strategy:'locked-https-artifact',kind,effectiveSpec:spec};
        default:
          unsupported(name,from,'materialization.'+kind,'effective edge has no supported materialization strategy');
      }
    }
    function admitArtifact(node,name,from){
      if(!node)fail('CLOSURE_UNPROVEN',name,from,'dependency is absent from the frozen graph');
      const location=node.resolution?.tarball;
      if(location===undefined&&semver.valid(node.meta.version))return; // Contracted canonical registry URL + mandatory SRI.
      if(typeof location!=='string')unsupported(name,from,'resolution.artifact','artifact locations must be explicit strings or a canonical locked registry version');
      if(location.startsWith('file:')){if(!archiveName(location.slice(5)))unsupported(name,from,'resolution.local-artifact','frozen file artifact locations must explicitly name a .tgz/.tar.gz/.tar; directory supply requires a concrete admitted link binding');return;}
      let url;try{url=new URL(location);}catch{unsupported(name,from,'resolution.artifact','unrecognized artifact location');}
      if(url.protocol!=='https:')unsupported(name,from,'resolution.'+url.protocol.slice(0,-1),'only local locked tar or HTTPS artifacts are modeled');
      if(url.username||url.password||url.search||url.hash)unsupported(name,from,'resolution.https-policy','authenticated URLs and URLs with query/hash are outside the anonymous immutable HTTPS artifact contract');
    }
    async function visitEdge(context,path,name,spec,key,from,physicalBundle=null){
      const plan=admitEdge(context,path,name,spec,key,from,physicalBundle);
      const edge={package:name,type:plan.kind,path:from,supportedShape:plan.strategy,declaredSpec:spec,declaredType:sourceKind(spec),effectiveSpec:plan.effectiveSpec,materialization:plan.strategy};
      if(physicalBundle)edge.inferredFrom='actual-packed-extra-version';
      if(plan.physical)edge.physicalTarget=plan.physical;
      if(plan.strategy==='npm-root-workspace')edge.resolution='npm-workspace-edge-precedence';
      sourceEdges.push(edge);
      switch(plan.strategy){
        case 'packed-bundle': case 'packed-bundle-extra': await visitBundle(context,plan.bundled,name,spec,key);return;
        case 'npm-root-workspace': case 'frozen-linked-directory': case 'packed-file': case 'packed-link': case 'packed-workspace':
          await visitNode(key,name,from,plan.effectiveSpec,plan.embedded);return;
        case 'locked-registry-artifact': case 'locked-https-artifact':
          await visitNode(key,name,from,spec);return;
        default:
          unsupported(name,from,'materialization.unadmitted','edge plan was not admitted by the supported strategy whitelist');
      }
    }
    async function visitNode(key,name,from,spec,embedded){
      if(!key)fail('CLOSURE_UNPROVEN',name,from,'dependency is absent from complete lock graph (including optional target)');
      const node=lock.node(key);incoming(node,null,name,spec,from);inspectNode(node);
      // Every actual file reference is bound to locked bytes, including reused nodes.
      if(embedded?.buffer)sri(embedded.buffer,node.resolution?.integrity,name,embedded.label);
      const id=lockfile+'#lock:'+key+(embedded?'!'+embedded.label+'!'+(embedded.path??'package/package.json'):'');if(visited.has(id))return;visited.add(id);
      const label=embedded?.label??lockfile+'#'+key;
      const map=embedded?.map??await manifests(embedded?.buffer??await bytes(node),label),path=embedded?.path??'package/package.json',pkg=map.get(path);
      incoming(node,pkg,name,spec,label+'!'+path);
      for(const [path,manifest] of map)if(installManifest(path))inspect({...manifest,optionalDependencies:undefined},label+'!'+path,findings);
      if(findings.length)throw new GateError(findings);
      await visitManifest({map,label,node,baseNode:node,packageRoot:posix.dirname(path),graphRoot:embedded?.graphRoot??'package',bindings:new Map()},path);
    }
    async function visitBundle(context,path,name,spec,expectedKey){
      const physicalKey=bundleKey(context,path);
      if(physicalKey&&expectedKey&&physicalKey!==expectedKey)fail('LOCK_DRIFT',name,context.label+'!'+path,'bundle lock location differs from incoming locked edge');
      const key=physicalKey??expectedKey,node=key?lock.node(key):null,pkg=context.map.get(path);
      incoming(node,pkg,name,spec,context.label+'!'+path);
      await visitManifest({...context,node},path);
    }
    async function visitManifest(context,path){
      const pkg=context.map.get(path),id=context.label+'!'+path,visitId=lockfile+'\0'+id;
      if(context.node)inspectNode(context.node);
      const shadowed=!context.node&&path===rootPath?workspaces:new Map();
      manifestShape(pkg,id,shadowed,path===rootPath);
      inspect(pkg,id,findings,shadowed);if(findings.length)throw new GateError(findings);
      context.bindings.set(path,context.node);
      if(visited.has(visitId))return;visited.add(visitId);
      await ownLocks(context,path);
      const selfContained=path!==rootPath&&!context.node;
      checked.push({name:pkg.name,version:pkg.version,path:id,lockNode:context.node?.key??null,evidence:selfContained?'self-contained-packed-bundle':'packed-manifest-and-lock'});
      if(selfContained)selfContainedBundles.push({name:pkg.name,version:pkg.version,path:id,reason:'no corresponding lock node; all install edges must be present and checked in this archive'});
      for(const name of bundles(pkg))if(!findBundle(context,path,name))fail('CLOSURE_UNPROVEN',name,id,'declared bundle missing from packed artifact');
      const lockedEdges=Object.entries(context.node?.edges??{}).map(([name,spec])=>[name,lock.format==='pnpm'&&typeof spec==='string'?spec.split('(')[0]:spec]);
      const edges=[...lockedEdges,...Object.entries(deps(pkg)),...(!context.node&&path===rootPath?[...workspaces.keys()].map(name=>[name,'workspace:*']):[])];
      for(const [name,spec] of edges){
        const bundled=findBundle(context,path,name);
        const key=context.node?context.node.ref(name):path===rootPath?lock.rootRef(name):null;
        if(bundled){await visitEdge(context,path,name,spec,key,id+'/dependencies/'+name);continue;}
        await visitEdge(context,path,name,spec,key,id+'/dependencies/'+name);
      }
      // Preserve both declarations and their optionality/ranges. Peers are not
      // ordinary install edges: only a truly absent optional peer may be omitted.
      const lockedPeers=context.node?context.node.peers:path===rootPath?rootPeers:[];
      for(const peer of [...lockedPeers,...peerDeclarations(pkg,id)]){
        const {name,spec}=peer,bundled=findBundle(context,path,name);
        const key=peer.resolved?peer.key:context.node?context.node.ref(name):path===rootPath?lock.rootRef(name):null;
        if(peer.resolved&&!key)fail('CLOSURE_UNPROVEN',name,peer.path,'explicit frozen peer binding has no resolved snapshot');
        if(!key&&!bundled&&peer.optional){
          const peerId=id+'\0'+name;let absent=absentPeerIds.get(peerId);
          if(!absent){absent={package:pkg.name,name,spec,path:id,declarations:[],reason:'optional peer absent from lock binding and packed archive is not automatically installed; not an optionalDependencies edge'};absentPeerIds.set(peerId,absent);absentOptionalPeers.push(absent);}
          absent.declarations.push({spec,path:peer.path});continue;
        }
        if(bundled){await visitEdge(context,path,name,spec,key,peer.path);continue;}
        await visitEdge(context,path,name,spec,key,peer.path);
      }
      // Parents before extras ensures pnpm snapshot association uses the owning bundle.
      if(path===context.packageRoot+'/package.json')for(const extra of [...context.map.keys()].sort((a,b)=>a.length-b.length))if(extra!==path&&extra.startsWith(context.packageRoot+'/')&&/^package\/.*node_modules\/(?:@[^/]+\/)?[^/]+\/package\.json$/.test(extra)&&!visited.has(lockfile+'\0'+context.label+'!'+extra)){
        const dir=extra.slice(0,-'/package.json'.length),at=dir.lastIndexOf('/node_modules/'),name=dir.slice(at+'/node_modules/'.length);
        const key=bundleKey(context,extra),node=key?lock.node(key):null;
        await visitEdge(context,context.packageRoot+'/package.json',name,node?.meta.version??context.map.get(extra).version,key,context.label+'!'+extra,extra);
      }
    }
    await visitManifest({map:packed,label:rootLabel,node:null,baseNode:null,packageRoot:posix.dirname(rootPath),graphRoot:posix.dirname(rootPath),rootLocksScanned,bindings:new Map()},rootPath);
  }
  await scan(packed,tarball,parseLock(await readFile(lockfile,'utf8'),lockfile),lockfile);
  if(findings.length)throw new GateError(findings);
  return {dependencyShapeContract:DEPENDENCY_SHAPE_CONTRACT,invariant:INVARIANT,disableable:false,reason:REASON,status:'PASS',package:root.name,version:root.version,tarballSHA256:digest(rootBuffer),lockfileSHA256:digest(await readFile(lockfile)),checkedPackages:checked.length,checked,checkedLocks,sourceEdges,absentOptionalPeers,selfContainedBundles,fetchedArtifacts:fetched,scope:'all platforms; packed artifact + bundles + locked production/optional/peer closure; unrelated development dependencies excluded'};
}
