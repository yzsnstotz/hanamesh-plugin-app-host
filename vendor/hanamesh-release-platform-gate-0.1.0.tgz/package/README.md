# DSH 发布正确性不变量：平台依赖闭包

编排转述 owner 2026-10-22 批准原话：「好，发布检查加上这条」。编排提供的背景：DSH bundled pnpm 11.7.0 对不适用平台 optional 子包可能安装完成后不退出，DSH 一直等待。本工具不宣称独立复现或修复了 pnpm。

**`DSH_PNPM_PLATFORM_CLOSURE` 是不可关闭的正确性不变量。** Mac、Windows、Linux 用同一规则；不以检查机的平台过滤。关掉它就可能发布用户无法完成安装的插件，故无 skip/allow/ignore 配置、环境开关、白名单或仅警告模式。触发时必须改依赖的分包方式，例如将多平台文件放进同一个平台中立包，或移除该依赖；不能以改 DSH、超时、重试、omit-optional 或隐藏限制代替。

## 检查什么

- 输入必须是**实际正常打出的 `.tgz`**和对应冻结锁。检查根清单、所有实际 bundled `node_modules/**/package.json`，支持 bundleDependencies/bundledDependencies 的数组和布尔形式。
- 支持 npm package-lock v2/v3、pnpm lock v9 根 importer/snapshots。沿发布 dependencies、optionalDependencies、完整锁快照传递边及必需/已解析 peer 遍历，不以本机 node_modules 或本机可安装平台代替完整闭包。与发布不可达的开发依赖不进入闭包，例如 Brand 的构建工具 esbuild。
- 每个包清单或锁元数据**存在**顶层 os/cpu/libc 字段即拒绝，包括空数组、否定条件以及匹配当前平台的值。optionalDependencies 指向平台子包也拒绝：同时检查引用名称/npm alias 和真实目标元数据。
- 名称分类是可见的保守规则，见导出的 `PLATFORM_TOKEN`：darwin/macos、win32/windows、linux/android、BSD、sunos/aix/haiku/os400/cygwin、arm/arm64/aarch64、x86/x64/ia32/x86_64、ppc64/s390x/riscv64/loong64/mips64el、musl/glibc 等以包名分隔符分开的 token。中性 optional 包允许；分类之外仍必须取真实目标包检查字段，不能仅靠命名规避。
- 依赖从锁定本地 `.tgz` 或匿名 HTTPS GET 读取，核强 SRI，再查**真实 tar 内容**；不安装或执行任何依赖脚本。缺节点、缺完整性、缺包、包与锁不符、未知锁格式、网络失败、损坏缓存都拒绝，不兜底。只读 artifact cache 使用完整性键，命中仍重新验 SRI。
- absent `peerDependenciesMeta.optional=true` 不是 optionalDependencies 安装边：不会自动安装，逐项写进 `absentOptionalPeers`；一旦锁中解析/实际 bundle 中存在就必须检查。依据 [npm peerDependenciesMeta 定义](https://docs.npmjs.com/cli/configuring-npm/package-json/#peerdependenciesmeta)。普通 optionalDependencies 即使本机没装也必须在完整锁中有证据。

每次 PASS/FAIL 都输出 JSON，包含不变量名、`disableable:false`、不能关闭的原因。FAIL 的 `findings` 列具体包名、archive/锁节点及触发字段路径、原因；退出1。PASS 含正常包/锁 SHA256 和已检查清单。无平台选择或阈值开关。

## 调用与发布接线

工具是单独的开发包，逻辑只有这一份；private=true 防止误发布本工具。不作为插件运行依赖，不带进插件产品包。G/I 先审交件并固定其正常包 SHA，作为 devDependency 接入；这里不改四仓或 devkit。

```sh
hanamesh-release-platform-gate --tarball artifacts/plugin.tgz --lockfile pnpm-lock.yaml
# npm 项目换成 --lockfile package-lock.json
# 可选 --source-root PATH 指定锁中本地 tar 的相对基准
# 可选 --artifact-cache PATH 复用经强 SRI 重新验证的 tar；无缺证据兜底

# 唯一发布工作流；check 只正常打包与检查，不发布
hanamesh-release check --lockfile pnpm-lock.yaml
hanamesh-release publish --lockfile pnpm-lock.yaml
```

`release check/publish` 执行一次正常 `npm pack`（正常生命周期，无 ignore-scripts），检查它实际生成的 tar，记录 `artifacts/release-platform/receipt.json`。publish 在最后再次核 SHA，只发布同一 tar，不重新从目录打包。四仓 `prepublishOnly` 接 `hanamesh-release source-guard`，明确拒绝直接从目录 npm publish，提示使用 `npm run release:publish`；CI 的发布权限也只能授予该受检入口。人为删除发布门、绕过工作流直接调用 registry 不是本地静态检查能授权的行为。

`release` 通过 Node 执行正常 npm JS 入口，无 shell 拼接或 npm.cmd 直接执行；请用 `npm run release:check/publish`，pnpm 可用于冻结安装，不能把它冒充 npm 的 pack 命令。Node >=24.13.1 <25。实际 npm 发布本次 NOT_RUN，未发 npm；Windows/Linux 真机执行 NOT_RUN，平台规则/夹具不依赖运行 OS，不能以 Mac 测试冒充真机证据。

## 测试与依据

`npm ci` 冻结安装开发工具后 `npm test`：正常、平台三轴/三系统、optional/peer、bundle、锁传递、缺证据、SRI、环、源码目录发布守卫及正常 pack 生命周期。正常工具 tar 可在独立目录安装后调用，不能借邻仓内部实现。

公开格式参考：[npm package.json](https://docs.npmjs.com/cli/configuring-npm/package-json/)、[package-lock](https://docs.npmjs.com/cli/configuring-npm/package-lock-json/)、[pnpm dependency resolution / supportedArchitectures](https://github.com/pnpm/pnpm/blob/main/pnpm/docs/settings/dependency-resolution.md)。说明中的 DSH pnpm 挂起事实来源于编排，本工具只验证可见包与闭包的不变量。
