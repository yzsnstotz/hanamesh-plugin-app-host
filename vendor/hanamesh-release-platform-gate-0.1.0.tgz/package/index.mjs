import {readFile, mkdir, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve, dirname, posix} from 'node:path';
import {Parser} from 'tar';
import YAML from 'yaml';
import semver from 'semver';

export const INVARIANT='DSH_PNPM_PLATFORM_CLOSURE';
export const REASON='Correctness invariant; cannot be disabled: DSH bundled pnpm 11.7.0 may not exit after processing inapplicable platform optional packages. All OS/CPU/libc targets must use one platform-neutral install dependency closure.';
// Visible conservative name classification. It complements actual manifest/lock metadata.
export const PLATFORM_TOKEN=/(?:^|[-_/])(?:darwin|macos|win32|windows|linux|android|freebsd|openbsd|netbsd|sunos|aix|haiku|os400|cygwin|arm64|aarch64|arm|x64|x86_64|ia32|x86|ppc64|s390x|riscv64|loong64|mips64el|musl|glibc)(?:$|[-_/])/i;
const fields=['os','cpu','libc'];
const object=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
const own=(a,k)=>Object.hasOwn(a,k);
const digest=b=>createHash('sha256').update(b).digest('hex');
export class GateError extends Error {
  constructor(findings){super(INVARIANT);this.findings=findings;}
}
const fail=(code,pkg,path,detail)=>{throw new GateError([{code,package:pkg,path,detail}]);};
function inspect(pkg,path,findings){
  if(!object(pkg))fail('EVIDENCE_INVALID','unknown',path,'package metadata must be an object');
  for(const field of fields)if(own(pkg,field))findings.push({code:'PLATFORM_FIELD',package:pkg.name??'unknown',path:path+'/'+field,detail:`${field} present: ${JSON.stringify(pkg[field])}`});
  if(pkg.optionalDependencies!==undefined&&!object(pkg.optionalDependencies))fail('EVIDENCE_INVALID',pkg.name,path+'/optionalDependencies','expected dependency map');
  for(const [name,spec] of Object.entries(pkg.optionalDependencies??{}))if(PLATFORM_TOKEN.test(name)||PLATFORM_TOKEN.test(String(spec).replace(/^npm:/,'')))findings.push({code:'PLATFORM_OPTIONAL',package:pkg.name??'unknown',path:path+'/optionalDependencies/'+name,detail:`platform subpackage reference ${name}: ${spec}`});
}
function deps(pkg){
  for(const field of ['dependencies','optionalDependencies','peerDependencies'])if(pkg[field]!==undefined&&!object(pkg[field]))fail('EVIDENCE_INVALID',pkg.name,'manifest/'+field,'expected dependency map');
  return {...pkg.dependencies,...pkg.optionalDependencies};
}
function bundles(pkg){
  const value=pkg.bundleDependencies??pkg.bundledDependencies??[];
  if(value===true)return Object.keys(deps(pkg));
  if(value===false)return [];
  if(!Array.isArray(value)||value.some(x=>typeof x!=='string'))fail('EVIDENCE_INVALID',pkg.name,'manifest/bundleDependencies','expected boolean or name array');
  return value;
}
async function manifests(buffer,label){
  const result=new Map();
  await new Promise((ok,no)=>{
    const parser=new Parser({strict:true,onReadEntry(entry){
      const path=entry.path.replace(/^\.\//,'');
      if(posix.isAbsolute(path)||path.split('/').includes('..')){no(new GateError([{code:'ARCHIVE_INVALID',package:'unknown',path:label,detail:'unsafe archive path'}]));entry.resume();return;}
      const wanted=path==='package/package.json'||/^package\/.*node_modules\/(?:@[^/]+\/)?[^/]+\/package\.json$/.test(path);
      if(!wanted){entry.resume();return;}
      if(entry.type!=='File'&&entry.type!=='OldFile'){no(new GateError([{code:'ARCHIVE_INVALID',package:'unknown',path:label+'!'+path,detail:'package manifest must be a regular file'}]));entry.resume();return;}
      if(result.has(path)){no(new GateError([{code:'ARCHIVE_INVALID',package:'unknown',path:label+'!'+path,detail:'duplicate package manifest'}]));entry.resume();return;}
      result.set(path,null);const chunks=[];
      entry.on('data',b=>chunks.push(b));entry.on('end',()=>{
        try{const pkg=JSON.parse(Buffer.concat(chunks).toString());if(!object(pkg)||typeof pkg.name!=='string'||typeof pkg.version!=='string')throw Error();result.set(path,pkg);}
        catch{no(new GateError([{code:'ARCHIVE_INVALID',package:'unknown',path:label+'!'+path,detail:'invalid package JSON/name/version'}]));}
      });
    }});
    parser.on('error',()=>no(new GateError([{code:'ARCHIVE_INVALID',package:'unknown',path:label,detail:'invalid tar archive'}])));
    parser.on('end',ok);parser.end(buffer);
  });
  if(!result.get('package/package.json'))fail('ARCHIVE_INVALID','unknown',label,'package/package.json missing');
  return result;
}
function parseLock(text,path){
  let lock;try{lock=path.endsWith('.json')?JSON.parse(text):YAML.parse(text,{uniqueKeys:true});}catch{fail('LOCK_INVALID','unknown',path,'invalid JSON/YAML');}
  if(!object(lock)||!object(lock.packages))fail('LOCK_INVALID','unknown',path,'packages required');
  if(path.endsWith('.json')){
    if(![2,3].includes(lock.lockfileVersion)||!object(lock.packages['']))fail('LOCK_UNSUPPORTED','unknown',path,'requires npm lockfileVersion 2/3');
    const map=lock.packages;
    return {format:'npm',root:map[''],rootRef(name){return lookup('',name);},get:key=>map[key],
      node(key){const data=map[key];if(!data||data.link)fail('CLOSURE_UNPROVEN',key,path+'#packages/'+key,'missing or linked npm record');return {key,meta:{name:data.name??key.split('node_modules/').at(-1),...data},edges:{...data.dependencies,...data.optionalDependencies},optional:data.optionalDependencies??{},ref:name=>lookup(key,name),resolution:{tarball:data.resolved,integrity:data.integrity}};}};
    function lookup(key,name){for(let at=key;;){const candidate=(at?at+'/':'')+'node_modules/'+name;if(own(map,candidate))return candidate;if(!at)return null;const i=at.lastIndexOf('/node_modules/');at=i<0?'':at.slice(0,i);}}
  }
  if(String(lock.lockfileVersion)!=='9.0'||!object(lock.importers?.['.'])||!object(lock.snapshots))fail('LOCK_UNSUPPORTED','unknown',path,'requires pnpm lockfileVersion 9.0 with root importer and snapshots');
  const root=lock.importers['.'];
  function lookup(name,ref){
    if(typeof ref!=='string')return null;
    const choices=ref.startsWith('npm:')?[ref.slice(4)]:[name+'@'+ref,ref];
    return choices.find(key=>own(lock.snapshots,key))??null;
  }
  return {format:'pnpm',root,rootRef(name){const ref=root.dependencies?.[name]??root.optionalDependencies?.[name]??root.devDependencies?.[name];return lookup(name,ref?.version);},
    get:key=>lock.packages[key?.split('(')[0]],node(key){
      const snapshot=lock.snapshots[key],base=key.split('(')[0],meta=lock.packages[base];
      if(!object(snapshot)||!object(meta))fail('CLOSURE_UNPROVEN',key,path+'#snapshots/'+key,'missing snapshot/package metadata');
      const split=base.indexOf('@',1);const name=base.slice(0,split),version=base.slice(split+1);
      return {key,meta:{name,version,...meta},edges:{...snapshot.dependencies,...snapshot.optionalDependencies},optional:snapshot.optionalDependencies??{},ref:name=>lookup(name,snapshot.optionalDependencies?.[name]??snapshot.dependencies?.[name]),resolution:meta.resolution};
    }};
}
function sri(buffer,integrity,name,path){
  if(typeof integrity!=='string')fail('CLOSURE_UNPROVEN',name,path,'locked integrity required');
  const tokens=integrity.split(/\s+/);const strongest=['sha512','sha384','sha256'].find(a=>tokens.some(s=>s.startsWith(a+'-')));
  if(!strongest)fail('CLOSURE_UNPROVEN',name,path,'strong SHA256/384/512 integrity required');
  const expected=createHash(strongest).update(buffer).digest('base64');
  if(!tokens.some(x=>x===strongest+'-'+expected))fail('INTEGRITY_MISMATCH',name,path,'locked artifact digest mismatch; no fallback');
}

export async function checkRelease({tarball,lockfile,sourceRoot,artifactCache}={}){
  if(typeof tarball!=='string'||typeof lockfile!=='string')fail('ARGUMENT_INVALID','release','arguments','tarball and lockfile required');
  tarball=resolve(tarball);lockfile=resolve(lockfile);sourceRoot=resolve(sourceRoot??dirname(lockfile));
  const rootBuffer=await readFile(tarball),packed=await manifests(rootBuffer,tarball),root=packed.get('package/package.json');
  const findings=[];for(const [path,pkg] of packed)inspect(pkg,tarball+'!'+path,findings);
  if(findings.length)throw new GateError(findings);
  const lock=parseLock(await readFile(lockfile,'utf8'),lockfile),rootDeps=deps(root);
  if(lock.format==='npm'&&(lock.root.name!==root.name||lock.root.version!==root.version))fail('LOCK_DRIFT',root.name,lockfile+'#packages/','lock root identity differs from packed release');
  for(const [name,spec] of Object.entries(rootDeps)){
    const got=lock.root.optionalDependencies?.[name]??lock.root.dependencies?.[name];
    if((lock.format==='pnpm'?got?.specifier:got)!==spec)fail('LOCK_DRIFT',root.name,lockfile+'#importer/'+name,'packed dependency spec differs from frozen root importer');
  }
  const visited=new Set(),metadataVisited=new Set(),checked=[],absentOptionalPeers=[];let fetched=0;
  function findBundle(context,manifestPath,name){
    let dir=posix.dirname(manifestPath);
    for(;;){const candidate=dir+'/node_modules/'+name+'/package.json';if(context.map.has(candidate))return candidate;if(dir==='package')return null;dir=posix.dirname(dir);if(dir==='.'||dir==='/')return null;}
  }
  async function bytes(node){
    let location=node.resolution?.tarball;
    if(!location&&semver.valid(node.meta.version)&&!node.meta.version.includes(':'))location=`https://registry.npmjs.org/${node.meta.name}/-/${node.meta.name.split('/').at(-1)}-${node.meta.version}.tgz`;
    if(typeof location!=='string')fail('CLOSURE_UNPROVEN',node.meta.name,lockfile+'#'+node.key,'locked tarball location required');
    const cache=artifactCache?resolve(artifactCache,digest(Buffer.from(node.resolution.integrity??''))+'.tgz'):null;
    let buffer;
    if(cache){try{buffer=await readFile(cache);}catch(e){if(e.code!=='ENOENT')throw e;}}
    if(!buffer){
      if(location.startsWith('file:')){
        const path=resolve(sourceRoot,location.slice(5));if(!path.endsWith('.tgz'))fail('CLOSURE_UNPROVEN',node.meta.name,lockfile+'#'+node.key,'local artifact must be an explicit tgz');buffer=await readFile(path);
      }else{
        let url;try{url=new URL(location);}catch{fail('CLOSURE_UNPROVEN',node.meta.name,lockfile+'#'+node.key,'unsupported artifact location');}
        if(url.protocol!=='https:'||url.username||url.password||url.search||url.hash)fail('CLOSURE_UNPROVEN',node.meta.name,lockfile+'#'+node.key,'only anonymous HTTPS artifact GET allowed');
        const response=await fetch(url,{redirect:'error'});if(!response.ok)fail('ARTIFACT_UNAVAILABLE',node.meta.name,lockfile+'#'+node.key,'artifact GET status '+response.status);
        buffer=Buffer.from(await response.arrayBuffer());fetched++;
      }
      sri(buffer,node.resolution.integrity,node.meta.name,lockfile+'#'+node.key);
      if(cache){await mkdir(dirname(cache),{recursive:true});await writeFile(cache,buffer,{flag:'wx'});}
    }else sri(buffer,node.resolution.integrity,node.meta.name,lockfile+'#'+node.key);
    return buffer;
  }
  async function visitNode(key,name,from,spec){
    if(!key)fail('CLOSURE_UNPROVEN',name,from,'dependency is absent from complete lock graph (including optional target)');
    const node=lock.node(key);
    if(semver.validRange(spec)&&semver.valid(node.meta.version)&&!semver.satisfies(node.meta.version,spec,{includePrerelease:true}))fail('LOCK_DRIFT',name,from,'locked version does not satisfy incoming dependency range');
    if(metadataVisited.has(key))return;metadataVisited.add(key);
    inspect(node.meta,lockfile+'#packages/'+key,findings);
    inspect({...node.meta,optionalDependencies:node.optional},lockfile+'#snapshots/'+key,findings);
    // Metadata evidence alone is sufficient to reject; never install an incompatible package to inspect it.
    if(findings.length){
      for(const [child,ref] of Object.entries(node.edges))if(node.ref(child))await visitNode(node.ref(child),child,lockfile+'#'+key,ref);
      return;
    }
    const id='lock:'+key;if(visited.has(id))return;visited.add(id);
    const buffer=await bytes(node),map=await manifests(buffer,lockfile+'#'+key);
    const pkg=map.get('package/package.json');
    const realName=String(spec).startsWith('npm:')?String(spec).slice(4).replace(/@[^@]*$/,''):name;
    if(pkg.name!==realName||semver.valid(node.meta.version)&&pkg.version!==node.meta.version)fail('LOCK_DRIFT',name,lockfile+'#'+key,'locked identity and actual artifact differ');
    if(semver.validRange(spec)&&!semver.satisfies(pkg.version,spec,{includePrerelease:true}))fail('LOCK_DRIFT',name,from,'actual version does not satisfy packed dependency');
    for(const [path,manifest] of map)inspect(manifest,lockfile+'#'+key+'!'+path,findings);
    if(findings.length)return;
    await visitManifest({map,label:lockfile+'#'+key,node},'package/package.json');
  }
  async function visitManifest(context,path){
    const pkg=context.map.get(path),id=context.label+'!'+path;if(visited.has(id))return;visited.add(id);
    if(context.node){inspect(context.node.meta,lockfile+'#packages/'+context.node.key,findings);if(findings.length)return;}
    checked.push({name:pkg.name,version:pkg.version,path:id});
    for(const name of bundles(pkg))if(!findBundle(context,path,name))fail('CLOSURE_UNPROVEN',name,id,'declared bundle missing from packed artifact');
    // Union actual package dependencies with the full lock snapshot, including
    // resolved peers/optional targets that a host-filtered install could omit.
    const edges={...context.node?.edges,...deps(pkg)};
    for(const [name,spec] of Object.entries(pkg.peerDependencies??{}))if(!own(edges,name)){
      const key=context.node?context.node.ref(name):lock.rootRef(name);
      if(!key&&pkg.peerDependenciesMeta?.[name]?.optional===true){absentOptionalPeers.push({package:pkg.name,name,spec,path:id,reason:'optional peer absent from lock is not automatically installed; not an optionalDependencies edge'});}
      else edges[name]=spec;
    }
    for(const [name,spec] of Object.entries(edges)){
      const bundled=findBundle(context,path,name);
      const key=context.node?context.node.ref(name):lock.rootRef(name);
      if(bundled){await visitManifest({...context,node:key?lock.node(key):null},bundled);continue;}
      await visitNode(key,name,id+'/dependencies/'+name,spec);
    }
    // Scan and traverse every actually bundled package, including undeclared extras.
    if(path==='package/package.json')for(const extra of context.map.keys())if(extra!==path&&!visited.has(context.label+'!'+extra)){
      const manifest=context.map.get(extra),key=context.node?context.node.ref(manifest.name):lock.rootRef(manifest.name);
      await visitManifest({...context,node:key?lock.node(key):null},extra);
    }
  }
  await visitManifest({map:packed,label:tarball,node:null},'package/package.json');
  if(findings.length)throw new GateError(findings);
  return {invariant:INVARIANT,disableable:false,reason:REASON,status:'PASS',package:root.name,version:root.version,tarballSHA256:digest(rootBuffer),lockfileSHA256:digest(await readFile(lockfile)),checkedPackages:checked.length,checked,absentOptionalPeers,fetchedArtifacts:fetched,scope:'all platforms; packed artifact + bundles + locked production/optional/peer closure; unrelated development dependencies excluded'};
}
