#!/usr/bin/env node
import {readFile as readTargets} from 'node:fs/promises';
import {checkRelease,GateError,INVARIANT,REASON,DEPENDENCY_SHAPE_CONTRACT,PLATFORM_CLOSURE_CONTRACT,INSTALLATION_RISK_CONTRACT} from './index.mjs';
const flags={'--tarball':'tarball','--lockfile':'lockfile','--source-root':'sourceRoot','--artifact-cache':'artifactCache','--installation-targets':'installationTargets'};
try{
  const args=process.argv.slice(2),options={};
  for(let i=0;i<args.length;i+=2){
    const key=flags[args[i]];
    if(!key||!args[i+1]||args[i+1].startsWith('--')||Object.hasOwn(options,key))throw new GateError([{code:'ARGUMENT_INVALID',package:'release',path:'arguments',detail:'only --tarball --lockfile --source-root --artifact-cache --installation-targets are accepted; no disable switch'}]);
    options[key]=args[i+1];
  }
  if(options.installationTargets)options.installationTargets=JSON.parse(await readTargets(options.installationTargets,'utf8'));
  process.stdout.write(JSON.stringify(await checkRelease(options))+'\n');
}catch(error){
  const findings=error instanceof GateError?error.findings:[{code:'EVIDENCE_UNAVAILABLE',package:'release',path:'release inputs',detail:'evidence read/parse/GET failed ('+(error.code??error.name)+'); no fallback'}];
  process.stdout.write(JSON.stringify({installationRiskContract:INSTALLATION_RISK_CONTRACT,platformClosureContract:PLATFORM_CLOSURE_CONTRACT,dependencyShapeContract:DEPENDENCY_SHAPE_CONTRACT,invariant:INVARIANT,disableable:false,reason:REASON,status:'FAIL',findings})+'\n');process.exitCode=1;
}
