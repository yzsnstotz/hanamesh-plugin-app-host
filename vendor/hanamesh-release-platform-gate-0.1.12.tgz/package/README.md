# DSH 发布正确性不变量：平台依赖闭包

历史来源（本版风险覆盖以 [INSTALLATION_RISK.md](INSTALLATION_RISK.md) 为准）：编排转述 owner 2026-10-22 批准原话：「好，发布检查加上这条」。编排提供的背景：DSH bundled pnpm 11.7.0 对不适用平台 optional 子包可能安装完成后不退出，DSH 一直等待。本工具不宣称独立复现或修复了 pnpm。

**`DSH_PNPM_PLATFORM_CLOSURE` 是不可关闭的正确性不变量。** Mac、Windows、Linux 用同一规则；不以检查机的平台过滤。关掉它就可能发布用户无法完成安装的插件，故无 skip/allow/ignore 配置、环境开关、白名单或仅警告模式。必需路径的平台限制须改为中立供给；完整可选平台子图同时核验闭包与 0.1.12 安装器资格；不能以改 DSH、超时、重试、omit-optional 或隐藏限制代替。

## 检查什么

- 输入必须是**实际正常打出的 `.tgz`**和对应冻结锁。检查根清单、所有实际 bundled `node_modules/**/package.json`，支持 bundleDependencies/bundledDependencies 的数组和布尔形式。
- 支持 npm package-lock v2/v3、pnpm lock v9 根 importer/snapshots。沿发布 dependencies、optionalDependencies、完整锁快照传递边及必需/已解析 peer 遍历，不以本机 node_modules 或本机可安装平台代替完整闭包。与发布不可达的开发依赖不进入闭包，例如 Brand 的构建工具 esbuild。
- 根及任一必需路径上的 os/cpu/libc 字段仍拒绝。完整可选子图在明确安装目标通过退出资格检查后允许合法选择器；每个目标仍核冻结绑定、真实归档、强 SRI、peer 和后续闭包。名称中的平台 token 仅对缺冻结证据的 optional 声明报 PLATFORM_OPTIONAL，不是拒绝合法工件的依据。
- 名称分类是可见的保守规则，见导出的 `PLATFORM_TOKEN`：darwin/macos、win32/windows、linux/android、BSD、sunos/aix/haiku/os400/cygwin、arm/arm64/aarch64、x86/x64/ia32/x86_64、ppc64/s390x/riscv64/loong64/mips64el、musl/glibc 等以包名分隔符分开的 token。中性 optional 包允许；分类之外仍必须取真实目标包检查字段，不能仅靠命名规避。
- 未由实际bundle满足的本地 `file:`/`link:` 依赖（普通、optional 与 peer 共用入口），必须从引用清单所在的**实际发布归档**相对位置展开目录或 `.tgz`/`.tar.gz`/`.tar`，归档核强SRI，目录核冻结 link/importer 目标；递归查真实清单、bundled/vendor 与包自身锁；不读取源码目录的同名vendor替代，正常postpack也不能改变受检输入。归档缺文件、越界路径、锁SRI不符即具名拒绝。
- bundle与外取依赖共用incoming名称/range、真实版本/锁版本、锁元数据及snapshot optional引用检查。npm extras按实际嵌套安装路径核锁，pnpm按最近所属包snapshot和原incoming节点关联，不回退根lookup丢节点。缺锁节点的bundle仅当所有安装边在同一实际归档内完全闭合才可通过，明确列入 `selfContainedBundles`；任何外部边缺锁即拒绝，不声称它已具备锁节点证据。
- registry 依赖从冻结锁定位的工件或匿名 HTTPS GET 读取，核强 SRI，再查**真实 tar 内容**；不安装或执行任何依赖脚本。缺节点、缺完整性、缺包、包与锁不符、未知锁格式、网络失败、损坏缓存都拒绝，不兜底。只读 artifact cache 使用完整性键，命中仍重新验 SRI。
- absent `peerDependenciesMeta.optional=true` 不是 optionalDependencies 安装边：不会自动安装，逐项写进 `absentOptionalPeers`；一旦锁中解析/实际 bundle 中存在就必须检查。依据 [npm peerDependenciesMeta 定义](https://docs.npmjs.com/cli/configuring-npm/package-json/#peerdependenciesmeta)。普通 optionalDependencies 即使本机没装也必须在完整锁中有证据。

每次 PASS/FAIL 都输出 JSON，包含不变量名、`disableable:false`、不能关闭的原因。FAIL 的 `findings` 列具体包名、archive/锁节点及触发字段路径、原因；退出1。PASS 含正常包/锁 SHA256 和已检查清单。无平台选择或阈值开关。

## 调用与发布接线

工具是单独的开发包，逻辑只有这一份；private=true 防止误发布本工具。不作为插件运行依赖，不带进插件产品包。G/I 先审交件并固定其正常包 SHA，作为 devDependency 接入；这里不改四仓或 devkit。

```sh
hanamesh-release-platform-gate --tarball artifacts/plugin.tgz --lockfile pnpm-lock.yaml
# npm 项目换成 --lockfile package-lock.json
# 可选 --source-root PATH 仅指定非packed file引用的锁工件相对基准；不能替代归档vendor
# 可选 --artifact-cache PATH 复用经强 SRI 重新验证的 tar；无缺证据兜底

# 唯一发布工作流；check 只正常打包与检查，不发布
hanamesh-release check --lockfile pnpm-lock.yaml
hanamesh-release publish --lockfile pnpm-lock.yaml
```

`release check/publish` 执行一次正常 `npm pack`（正常生命周期，无 ignore-scripts），检查它实际生成的 tar，记录 `artifacts/release-platform/receipt.json`。publish 在最后再次核 SHA，只发布同一 tar，不重新从目录打包。四仓 `prepublishOnly` 接 `hanamesh-release source-guard`，明确拒绝直接从目录 npm publish，提示使用 `npm run release:publish`；CI 的发布权限也只能授予该受检入口。人为删除发布门、绕过工作流直接调用 registry 不是本地静态检查能授权的行为。

`release` 通过 Node 执行正常 npm JS 入口，无 shell 拼接或 npm.cmd 直接执行；请用 `npm run release:check/publish`，pnpm 可用于冻结安装，不能把它冒充 npm 的 pack 命令。Node >=24.13.1 <25。实际 npm 发布本次 NOT_RUN，未发 npm；历史版本的 Windows/Linux 真机执行为 NOT_RUN；0.1.12 的 macOS arm64 与 Linux arm64 范围及证据见 INSTALLATION_RISK.md，不扩大到其它系统。

## 测试与依据

`npm ci` 冻结安装开发工具后 `npm test`：正常、平台三轴/三系统、optional/peer、bundle、锁传递、缺证据、SRI、环、源码目录发布守卫及正常 pack 生命周期。正常工具 tar 可在独立目录安装后调用，不能借邻仓内部实现。

公开格式参考：[npm package.json](https://docs.npmjs.com/cli/configuring-npm/package-json/)、[package-lock](https://docs.npmjs.com/cli/configuring-npm/package-lock-json/)、[pnpm dependency resolution / supportedArchitectures](https://github.com/pnpm/pnpm/blob/main/pnpm/docs/settings/dependency-resolution.md)。说明中的 DSH pnpm 挂起事实来源于编排，本工具只验证可见包与闭包的不变量。

## 0.1.1 返修记录（R1 已拒收）

针对R1 docs c0f81590d 的R1-RPG-01/02/03：实际vendor与锁绑定、bundle/嵌套extra锁闭包统一、修正optional spec路径误报，并纠正实际bundle中的optional peer被重复列absent的诊断。版本0.1.0/stage94561328d已被R1拒收，不作为可接线版本。具体TDD首红、原R1夹具复核、正常包及四插件验证见编排交件，独审未出前不声称放行。

不变量仍不可关闭；遇到真实os/cpu/libc字段或平台目标名称仍拒绝，路径误报修正不是放宽平台断言。修复不会禁正常pack/postpack，不读源码vendor充当发布工件，也不使用重试、超时、跳过或人工保证同字节来通过。

## 0.1.2 peer 闭包返修说明（R1 已拒收）

针对 R1-RPG-04（177110679）：冻结锁与实际归档的 peer 声明分别保留并检查，不能以打包时移除清单声明抹掉锁中已解析的 peer，也不能让同名 dependencies 覆盖 peer 的范围或 required 约束。npm 按物理安装路径解析锁独有的 peer；pnpm 同时检查 packages、snapshots 声明和快照键中的显式 peer 绑定，支持 scoped 和嵌套 peer 上下文，不按全局同名包猜测绑定。显式绑定缺目标时拒绝，不能归类为 absent optional。每条已声明范围都校验，真正无绑定且无 bundle 的 optional peer 才列 absent。

0.1.0 与 0.1.1 均已被 R1 拒收；四仓接线须等待本候选独审，不能继续固定旧版。新增原 R1 18 项复现和 npm/pnpm 边界回归，覆盖正常 npm install → ci → release check/prepack 路径。不可关闭不变量及触发原因保持公开；本返修不修改 DSH 或四个插件，不发 npm。


## 0.1.3 来源闭包返修（R2 已拒收）

承接 R1 docs 8fe0896ed / R1-RPG-05。0.1.2 的 file peer 漏传实际内层归档，使强 SRI 校验了 sourceRoot 的另一份字节。现普通/optional/peer 都走同一个来源入口；每条冻结声明与实际声明分别保留，同名边不能覆盖另一条的来源和约束。读取实际归档前后均无源码vendor兜底，cache命中也不跳来源策略或SRI。不能据作者测试认为独审通过，0.1.0–0.1.2均不可接线。

每个实际包根的 `npm-shrinkwrap.json`、`package-lock.json`、`pnpm-lock.yaml` 都作为独立图遍历，与外层冻结图同时检查；多个锁全查，不用一个覆盖另一个。锁节点去重包含锁身份，避免两个图同名节点互相抵消；循环保护只防重复遍历。内层锁的本地工件只能从该实际归档展开。缺目标、缺强SRI、锁/实际包身份或范围矛盾、未知锁格式均拒绝。模块内部只声明type的 `dist/commonjs/package.json` 不是安装包根，不能误当一个缺name/version的依赖；真实包根的os/cpu/libc断言不变。

| 来源类型 | 处理与明确边界 | 回归证据（test/source-closure.test.mjs，另含原测试） |
|---|---|---|
| registry | npm版本/范围/tag及npm alias按冻结图取真实包，强SRI、名称/版本/range与传递/optional/peer均查；pnpm显式peer context保留绑定，不能当版本或全局猜目标 | 原普通/alias/peer/环/缺节点/SRI用例；新增pnpm带peer context的冻结依赖与四固定正常包 |
| git | 已被实际bundle满足时查该bundle完整闭包；未materialize的git/托管简写具名SOURCE_UNSUPPORTED，不checkout、不执行prepare、不用registry同版本替换 | 固定commit、GitHub简写及.tgz结尾git URL拒绝；实际bundle中性通过、平台拒绝 |
| file | 相对本地归档从发布tar读取并按锁强SRI；目录必须实际在tar内且与冻结link/importer目标一致；绝对/越界/缺失拒绝 | 依赖/optional/必需peer/已解析optional peer、递归vendor/bundle、SRI错配、缺包、越界、目录绑定及包自身三种锁 |
| link | 只展开实际归档中明确的目录目标，核冻结link目标，再查清单、bundle/vendor/自身锁；不访问机器node_modules或外部软链接 | npm具体link记录与pnpm importer/link-only形态；目录平台与锁独有平台拒绝、缺外部依赖拒绝 |
| tarball | 本地.tgz/.tar.gz/.tar沿file处理；远端只允许与锁一致的匿名HTTPS URL和强SRI，缓存命中仍验；取出的包同样递归查自身锁与bundle/vendor | 本地两种压缩命名、HTTPS强SRI cache正常/平台、URL漂移及HTTP cache拒绝；无真实远端发布 |
| workspace | 已bundle时按实际bundle查；否则必须有冻结link引用并有实际目录，解析可用importer；缺目录/缺闭包拒绝，不从源码找工作区 | workspace中性/平台bundle、npm具体link与pnpm正常workspace锁；missing workspace拒绝 |
| bundled | 实际node_modules安装根按物理嵌套路径/所属snapshot关联，检查所有extras及自身锁；无锁者仅可完全自包含，已显式记录 | 原数组/布尔、scoped/嵌套、锁独有平台、range、缺锁不自包含；新增local peer内bundle与模块type清单 |
| vendor | 这是包内存放位置，不是独立协议；每条file/link指向的真实vendor归档/目录按上述规则展开，不读postpack恢复后的源文件替代 | R1原19/20/21只读首红回放、正常install→ci→prepack替换/postpack恢复、递归peer vendor、自身锁本地工件错配 |

`link`/`workspace`/git已bundle的通过只证明本不变量要求的实际平台闭包；不宣称所有包管理器接受该发布格式、仓库脚本安全、DSH可安装或宿主验收通过。pnpm源ref不是semver版本；有真实version元数据时核它，否则用强SRI的实际包版本与incoming范围，不把file:路径冒充版本。pnpm只有link的正常锁可省packages/snapshots；可用本地importer照查，缺锁节点的外部边仍拒绝。

PASS额外列 `checkedLocks` 和 `sourceEdges`，便于看实际来源与materialization；其余输出与不可关闭规则保持。真实pnpm11.7的本地tarball/link/workspace供给单独保留install及frozen-install日志和不变tar/锁回放。正常npm pack/release生命周期继续执行，不禁prepack/postpack。本工具不承担公共发布授权。


## 0.1.4 同归档兄弟目录返修（R2 已拒收，RPG-06具体项已关闭）

针对 docs 8855e96cb / R2-RPG-06：目录依赖不再裁剪成虚拟新归档。每个遍历上下文保留真实 tar 的完整清单/工件/锁、清单物理路径、当前包根和冻结图根；file/link 相对引用清单解析，workspace 目标相对所属图根解析，目录路径再与该图的具体冻结目标核对。包自身锁开启独立图但沿用原 tar 的物理坐标；只有真正解开内层 tar 才建立新归档边界。因此同一实际 tar 的中立兄弟目录允许，越出真正 tar、借外层 tar 补内层缺包、冻结目标漂移、SRI 错配及真实平台字段仍拒绝。bundled 查找保留同一 tar 内上层安装位置，extras 限于当前实际包的子树。

新增 `test/sibling-closure.test.mjs` 覆盖 file/link/workspace 的 ordinary/optional/peer 兄弟边、中立通过与实际平台拒绝、兄弟 tar 强 SRI、npm/pnpm 自身锁的独立图坐标、真正越界/内外层 tar 隔离/目标漂移、环与提升的 bundle，以及正常 npm install → ci → npm run release:check。上表八类来源规则及原回归继续适用；R2 原32项与原正常 npm tar/锁独立只读重放。0.1.3 已被 R2 拒收；0.1.4 仍须编排转独审，四仓接线继续等待。


## 0.1.5 npm 路径语义返修（R2 已拒收）

承接 docs4c5a974b5 / R2-RPG-07。R2原%20样本确实误拒，但根因不能简化为“所有file路径做decodeURIComponent”：固定npm11.8.0所用npm-package-arg13.0.2将普通file中的百分号当字面字符；根workspaces则先创建按包名选择实际目录的workspace边，再优先于同名production/optional/peer声明。真实npm对照证明：编码空格/Unicode/大小写不同甚至不同路径文本，根workspace仍选实际匹配目录；无workspace的编码空格输入虽install/ci可exit0，但可能只生成缺目标的空link，真实require失败，不能当合法闭包PASS。

现在使用固定 `@npmcli/map-workspaces@5.0.3` 的 **virtual** 匹配器，仅输入真实tar清单和冻结记录，不运行其文件系统glob。由实际包名与声明pattern建立唯一workspace映射，具体实际目录必须与冻结link目标完全相同；根workspace的自动安装边也全部进入闭包，即使未显式列入dependencies。实际/冻结workspace缺包、缺link、名称冲突、声明漂移均拒绝。根的每条原声明和incoming约束继续分别检查；不以workspace删除原peer范围或实际平台断言。PASS的sourceEdges明确记录 `resolution:npm-workspace-edge-precedence` 与 `physicalTarget`，不做静默源码回退。

普通file/link、冻结目标键及tar文件名不进行盲解码、重复解码、Unicode归一或大小写折叠；字面%20/%2520/%zz/#/?等名字仍按真实冻结坐标处理。真正跨归档/绝对/父目录路径门保持，百分号分隔符不能借解码逃到文件系统。npm已知workspace的物理目标可处理编码/字面空格、Unicode及大小写引用差异；该结论不扩大到未证明的包管理器或未打入实际tar的目录。

符号链接：正常源目录alias若被npm workspace绑定到已实际打入tar的具体目标，检查该目标；普通alias若未进入tar则CLOSURE_UNPROVEN，不用sourceRoot跟随机器软链补包；tar内清单软链接仍ARCHIVE_INVALID。测试同时保留可接受和拒绝路径。Unicode NFC/NFD与%十六进制大小写在普通文件名中保持独立；不借macOS文件系统的大小写/Unicode行为放宽跨平台归档比较，其他OS真机NOT_RUN。

`test/npm-paths.test.mjs`包含正常npm install→ci→真实require→release:check（prepack/postpack各一次）、正常symlink正反对照、原编码/字面路径、实际leaf平台反例、workspace自动边、缺包/冻结漂移/重复名、glob排除再包含、物理字面%与Unicode/大小写隔离。旧RPG-06及八类registry/git/file/link/tarball/workspace/bundled/vendor回归全保留。本工具仍private，不发npm，独审前不接四仓。

规则依据：[npm11.8.0 workspace边优先级源码](https://github.com/npm/cli/blob/v11.8.0/workspaces/arborist/lib/node.js)、[npm-package-arg13.0.2路径源码](https://github.com/npm/npm-package-arg/blob/v13.0.2/lib/npa.js)、[npm workspaces文档](https://docs.npmjs.com/cli/v11/using-npm/workspaces/)。修复使用实际固定版本及正常生命周期证明，不将install退出0等同于真实闭包存在。


## 0.1.6 有限依赖形态合同与 RPG-08（R2已拒收）

0.1.5 已被 docs837c67873 拒收：RPG-07 关闭，但 RPG-08 的 npm workspace 覆盖仍误拒。根因是来源已选成 workspace，incoming 却继续校验被覆盖的原声明版本/alias。现按 npm 根实际 workspace 边校验，sourceEdges 公开 declaredSpec/effectiveSpec/physicalTarget；真实子包 peer、平台字段、冻结身份与强 SRI 断言均保留。

本门支持边界以随正常工具包交付的 [支持的依赖形态合同 dependency-shapes-v1](DEPENDENCY_SHAPES.md) 为准。合同覆盖 registry/git/file/link/tarball/workspace/bundled/vendor 的明确子集，npm v2/v3 与 pnpm v9 的有限 grammar；**合同外一律具名拒绝 UNSUPPORTED_DEPENDENCY_SHAPE**，输出具体 shape、why、action、contract，release 失败回执持久化。overrides/resolutions/pnpm 改写、patch/catalog/injected 等扩展、未知锁字段/协议/版本不猜测、不隐藏、不静默放行。合同内证据缺失/平台违规仍以原具名错误拒绝。R2 的审查范围就是该合同：合同内零漏查零误拒，合同外具名拒绝；不再逐边角追无限解析器行为。

新增合同用例、原 R2 三例正常 npm 生命周期及原 tar/锁重放、四插件当前正式包/锁独立读回均随交件提供；作者验证不等于独审通过。0.1.0–0.1.5 均不可接线。本候选 private=true，未发 npm、未改四仓或客户端、未部署。


## 0.1.7 白名单式准入与 workspace 子边（候选，待 R2）

R2 docs dc0e2dcbe：RPG-08具体误拒可关，但RPG-09表明0.1.6没有把合同准入接到图根/自身锁新根/部分pnpm importer；RPG-10表明真实semver子边已冻结到本地workspace却错误向registry取包。0.1.6仍不可接线。

本版把metadata grammar、声明类型与物理供给分派明确分开：npm所有根/普通记录同一字段白名单，pnpm全部importer/peer metadata预检，bundle双拼写/workspaces对象/解析字段类型具名准入；每条有效安装边必须得到合同supportedShape白名单中的一个计划，未知声明/物理策略的default一律UNSUPPORTED_DEPENDENCY_SHAPE。未声明实际bundle extra同样走准入；不因bundle满足而信任未知协议。registry/git用固定npm-package-arg13.0.2核声明类型，仍不执行checkout/prepare。合同外shape/why/action在检查输出及失败receipt公开，不能静默PASS。完整有限边界及策略表见[合同](DEPENDENCY_SHAPES.md)。

RPG-10保留真实child semver/peer/alias范围，只按具体冻结link取实际tar内目录，不改成*、不加SRI把它伪装registry包、不请求同名registry替代。根workspace已覆盖声明的既有优先级保持。真实平台字段、SRI、名称/版本/目录漂移、缺目标继续拒绝。R2原始输入首红、正常install→ci→runtime→release check与原回归随交件，作者验证不代表独审放行。private=true，未发npm、未改四仓/客户端或部署；四仓接线等待编排转R2。

## 0.1.8 npm 预发行范围语义（候选，待 R2）

R2 docs eab304204：RPG-09/10 原例可关；0.1.7 的 incoming 无条件 includePrerelease 扩大了原范围，RPG-11 四个错误 PASS，0.1.7 不可接线。0.1.8 移除此全局选项，按 npm 11.8.0 / Arborist 9.1.10 的默认预发行排除和显式预发行范围处理 prod/optional/peer、alias 与真实 workspace 子边。只保留 npm 自身对字面 `*` 的既有目标接受语义，不把 x 或 >=0.0.0 的归一范围当作该例外；不重写原声明。

原字节 R2 四负例必须返回 LOCK_DRIFT，显式预发行/稳定正例保持；完整合同见 DEPENDENCY_SHAPES.md。合同外继续具名 UNSUPPORTED_DEPENDENCY_SHAPE，无默认放行。正常工具 tar、外部消费者与四插件正式包验证见同次交件；作者绿不代表 R2 放行，private=true，未发 npm，未接四仓。

## 0.1.9 alias 空白与具名错误分类（候选，待 R2）

R2 docs 544228ee0：RPG-11原例可关；RPG-12正常npm alias的真实换行空白被后续手写正则误报invalid alias。0.1.9统一用固定npm-package-arg13.0.2提取alias目标与规范化fetchSpec，保留原声明、npm预发行语义、平台/身份/范围/闭包核验；正常Tab/LF/CRLF及scoped alias纳入合同，嵌套或非registry目标具名UNSUPPORTED_DEPENDENCY_SHAPE。

按编排收尾标准，合同外认证/query/hash HTTPS、绝对/反斜线本地坐标、非显式本地归档位置与无法建模的workspace模式均具名UNSUPPORTED（形态/原因/处理建议可见），不再以通用缺证据掩盖限制；具体shape见DEPENDENCY_SHAPES.md。真实缺文件/强SRI/绑定保持CLOSURE_UNPROVEN，真实冻结矛盾保持LOCK_DRIFT，损坏输入/实际读取处理失败保持各自理由。完整错误出口清单与首红/诊断迁移随本次交件，不能把“拒绝了”当“理由正确”。合同内零漏零误拒、合同外具名拒绝，无默认放行；作者验证待R2，private=true，未发npm、未接四仓。


0.1.10 修正 pnpm 循环 peer context 的目标解析：优先取同一 snapshot 有效 dependencies/optionalDependencies 边的完整冻结目标，核对精确 name@version；缺目标仍失败，不回退、不跳过平台/optional/peer/完整闭包检查。依赖形态合同及既有规则不变。


### 0.1.11 可选平台路径合同

`optional-platform-paths-v1` 扩展见 [DEPENDENCY_SHAPES.md](DEPENDENCY_SHAPES.md#0111-平台可选路径审查-optional-platform-paths-v1pk2)。必需路径必须中立；合法平台选择器只允许出现在完整可选子图，仍扫描并校验所有平台工件、锁、peer 与强 SRI。同一节点后续经必需路径可达仍拒绝；不依赖包名白名单、主机过滤或关闭门。此前“所有平台字段一律拒绝”的描述只代表 0.1.10 及更早的历史策略，此节为现行 0.1.11 审查契约。


## 0.1.12 安装器退出资格

`optional-platform-paths-v1` 的完整闭包证据不足以替代安装器退出验证。平台 optional 子图必须附显式 `installationTargets` / `--installation-targets PATH` 矩阵；本版只接受 DSH 0.2.2-rc.1 / pnpm 11.28.5 的 darwin-arm64 与 linux-arm64。旧 pnpm 11.7.0 组合必拒，未供给或未知组合也拒绝，所有平台工件仍完整扫描。正常中立闭包保持原用法。原始首错的未取得边界、上游修复依据与实际两平台验证范围见 [安装退出风险合同](INSTALLATION_RISK.md)。

```json
[{"dsh":"0.2.2-rc.1","pnpm":"11.28.5","os":"darwin","cpu":"arm64"},{"dsh":"0.2.2-rc.1","pnpm":"11.28.5","os":"linux","cpu":"arm64"}]
```

```sh
hanamesh-release-platform-gate --tarball artifacts/plugin.tgz --lockfile pnpm-lock.yaml --installation-targets installation-targets.json
hanamesh-release check --lockfile pnpm-lock.yaml --installation-targets installation-targets.json
```
