# DSH / pnpm 安装退出风险合同

合同 `dsh-pnpm-platform-exit-v1`，自 0.1.12 起与 `optional-platform-paths-v1` 同时执行。闭包完整性与安装器退出是两项独立条件；合法 optional 平台元数据或强 SRI 不能独自证明退出。

## 原风险与来源边界

2026-10-22 的初版平台门依据编排转述：官方 DSH bundled pnpm 11.7.0 处理不适用平台 optional 包后可能不退出。历史交件明确没有独立复现。PG1 在文档仓、编排 ORCH-HANDOFF/questions 及现存 mini 同路径检索，没有取得这次原始挂起的独立首错进程日志；不能补造具体 DSH 构建、OS、包名或网络时序。同期独立 DSH 记录为 0.2.0-rc.2 / pnpm 11.7.0 / macOS arm64，但这只是同期版本证据，不能当作该次挂起的完整复现。

上游 [pnpm#12297](https://github.com/pnpm/pnpm/issues/12297) 最初报告 Linux x64 / Node 24.12.0 / pnpm 11.5.1 的间歇安装完成后不退出。[修复 #13226](https://github.com/pnpm/pnpm/pull/13226) 确定 worker 池结束后的迟到任务会重新创建无人结束的池；不安装到主机的 optional 平台包发生延迟抓取是该时序的一种来源。修复保留已结束的池，让迟到任务的 worker 在归还时退出；[11.23.0 发行说明](https://github.com/pnpm/pnpm/releases/tag/v11.23.0) 收录该修复。这不是“每个 optional 包、每次安装都会挂起”的断言。

门对 pnpm 11.0.0 至 11.23.0 之前的版本保守拒绝带平台元数据的可选闭包，错误码 `PNPM_PLATFORM_HANG_RISK`。此区间是风险筛选区间，不宣称逐版实测或确定首次引入版本。旧 DSH 0.2.0-rc.2 / pnpm 11.7.0 的反例必须红。

## 本版可放行的明确安装目标

| DSH | 实际 pnpm | OS | CPU |
|---|---|---|---|
| 0.2.2-rc.1 | 11.28.5 | darwin | arm64 |
| 0.2.2-rc.1 | 11.28.5 | linux | arm64 |

[官方 DSH 固定标签桌面声明](https://github.com/deepseek-ai/deepseek-harness/blob/dsh-v0.2.2-rc.1/apps/desktop/package.json) 固定 pnpm 11.28.5；npm CLI 不附带同一可执行文件，沿调用环境选择 pnpm。因此版本必须来自实际安装环境，不能仅从 DSH 版本推断。PK2 的 pnpm 10.33.0 记录不是 bundled 11.28.5 的验证。

PG1 使用官方 npm DSH CLI `plugin --profile … add --save-exact`、固定 Node 24.13.1、隔离 HOME/DSH_HOME/store，安装正常 AppHost 0.6.24 归档（SHA256 `fce7b8066fce1945295d8977b4ca2a48807060bbcf7b141e7c747ab33e1a64f6`）。全闭包消费者在安装前显式声明正常官方 peer 提供方及 app-boot 0.2.2-rc.1；不改变 DSH 默认 peer 策略。冻结图完整保留 node-addon-require-builtin 0.1.9 的九个 darwin/linux/win32 optional 叶子。两平台实际退出证据见 PG1-delivery / PG1-gate-handoff；Linux 为 mini 的固定 colima ci / act Ubuntu arm64，macOS 为 mini 原生 arm64。不是 Desktop GUI 或九种目标系统的真机验收。

本门只承诺上述明确组合和本次正常闭包的退出证据，不把高版本、其它 Node/OS/CPU、相邻 DSH 或不同包管理器推定安全；不声称消除所有安装挂起。未知组合需要新增独立验证并评审合同。中立闭包仍可按原合同供旧安装器使用。

## 调用与拒绝规则

对带合法平台选择器的 optional 子图，API 必须显式传 `installationTargets` 非空数组，每项恰为 `{dsh,pnpm,os,cpu}`；CLI / release 入口传 `--installation-targets PATH`，文件内容为该数组。两个版本必须为精确语义版本，不能是范围；这是发布者声明的完整拟支持安装矩阵，不是检查机的运行环境。调用者负责从实际供给工具链核对版本，本门不会启动个人 DSH 探测或读取其状态。

缺矩阵 `INSTALLATION_TARGETS_REQUIRED`；格式或未验证组合 `INSTALLATION_TARGET_UNSUPPORTED`；任意一项属于旧风险组合即 `PNPM_PLATFORM_HANG_RISK`。必须所有目标通过，不能混入一个新组合把旧组合洗绿。不可通过环境变量、空矩阵、omit-optional 或当前主机选择缩小被扫描的依赖图。未传矩阵时不会自动采用本机或最新 DSH；原 .11 消费入口需显式更新后才能放行平台 optional 闭包。

必需安装路径上的平台字段仍直接 `PLATFORM_FIELD`；缺工件、弱/错误 SRI、冻结边/选择器漂移、必需路径与可选路径重复到达、未建模选择器等原检查均保留。矩阵只决定已完整核验 optional 平台子图的安装器资格，不能豁免任何实际工件。PASS/FAIL 回执都带 `installationRiskContract`，PASS 同时保留声明的 `installationTargets`。
