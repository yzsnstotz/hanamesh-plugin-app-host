# @hanamesh/lib-provision

**状态：DELIVERED · 0.1.0-rc.1 · P01–P06、P08、P09、X01–X03 PASS（本机真实网络 + 真实 SIGKILL）；P07 Windows 真实门 NOT_RUN（PLAT，需 mayn）。完整记录与原始输出：`docs/acceptance/P.md` 与同目录 `raw/`、`mutations/`。ACCEPTED 由用户亲跑 P01 后给出。**

把「把一个大文件安全地放到用户机器上」做成唯一实现：**选源 → 可续传下载 → sha256 必须等于 manifest → 解压到 root 内唯一 staging → 可选 `verify.exec` → 原子提升 → 账本**。任一步失败：staging 清理、已落位的不动。它不猜任何东西——来源、摘要、目标路径全部来自调用方给的 manifest；唯一的「探测」是 `process.platform-process.arch`。

零运行时依赖（tar.gz / zip 读取用 Node 内置 `zlib` 自写；HTTP 用 Node 24 自带 `fetch`）。不支持 `.tar.xz`。

## 实际环境

| 项目 | 本次实测 | 产品目标 |
|---|---|---|
| 系统 | macOS darwin-arm64（Darwin 25.3.0） | macOS / Windows / Linux 四平台；Windows 仅纯函数单测 |
| Node / npm | 24.13.1 / 11.8.0 | Node 24.13.1，`engines` `>=24.13.1 <25` |
| TypeScript | 5.9.3（devDependency 钉死） | 5.9.3，`strict` + `exactOptionalPropertyTypes`，`skipLibCheck=false` |
| 运行时依赖 | 无 | 无 |
| 真实网络 | nodejs.org 官方 `node-v24.13.1-darwin-arm64.tar.gz`（sha256 取自官方 `SHASUMS256.txt`） | GitHub Releases / CN 反代 / 离线 `file:` |

## 用法

```sh
npm install /abs/path/hanamesh-lib-provision-0.1.0-rc.1.tgz
```

```ts
import { plan, provision, verify, remove, platformKey } from '@hanamesh/lib-provision';

const manifest = JSON.parse(await fs.readFile('node-24.13.1.json', 'utf8'));
const root = '/Users/me/Library/Application Support/HanaMesh';

for (const e of await plan(manifest, { root })) console.log(e.item, e.state);   // absent | installed | stale | unsupported
const results = await provision(manifest, {
  root,
  onProgress: (e) => console.error(e.item, e.phase, e.source, e.bytes, e.total, e.note),
  sourceOrder: ['cn', 'direct'],   // 可选：只用这些源、按这个顺序
});
await verify({ root });            // 按所有权清单重算摘要、修复账本
await remove('node', { root });    // 只删清单里列出的文件
```

CLI（进度到 stderr，JSON 结果到 stdout，退出码非 0 = 没做完；不需要 PATH/HOME）：

```sh
hanamesh-provision plan    manifest.json --root <dir>
hanamesh-provision install manifest.json --root <dir> [--source cn]... [--only node]... [--force]
hanamesh-provision verify  --root <dir>
hanamesh-provision remove  node --root <dir>
hanamesh-provision platform
```

`docs/acceptance/manifests/node-24.13.1.json` 是一份可直接用的 manifest（官方 Node 24.13.1 四平台，摘要来自 `docs/acceptance/raw/nodejs-SHASUMS256.txt`）。

## Manifest（调用方给，本库只执行）

见 `lib/index.d.ts` 的 `Manifest` 类型。要点：

- `sources[]` 按顺序尝试；`kind` 只能是 `https` / `file`，`base` 协议必须一致。`http:`、`ftp:` 等在校验阶段就拒绝；下载时重定向到非 `https:` 也拒绝。
- 每个 item 的 `platforms[<platformKey>]` 必须带 64 位小写 hex `sha256`，缺了整个 item 拒绝——**不猜摘要**。可选 `size`、`strip`（剥掉的顶层目录层数）、`url`（该资产的绝对 URL，绕过 `sources`）。
- `installTo` 是 root 内的相对 POSIX 路径，不得进 `.provision/`。
- `verify.exec` 是解压后树内的相对路径；以**绝对路径**执行**刚解出的**文件，`env` 只有 `PATH=''`（Windows 加 `SystemRoot`），从不用宿主 PATH。
- 缺当前平台条目的 item 记为 `unsupported`，不报错。

## 磁盘布局与原子提升

```
<root>/
  .provision/ledger.json                 账本（temp + fsync + rename 原子写）
  .provision/staging/<item>-<sha12>/     唯一 staging（下载的 archive、.part、.part.json、tree/）
  .provision/trash/<ts>-<item>/          升级时旧版临时停放（成功后删除；verify 能原样放回）
  .provision/pending/<item>.json         提升进行中的意向记录（verify 据此发现未登账的树）
  <installTo>/                           目标树
  <installTo>.manifest.json              所有权清单：文件清单 + 每文件 sha256 + symlink + 目录
```

提升顺序（每步落盘后才做下一步，任一步失败回滚到旧状态）：

1. 写 pending 记录；写 `<target>.manifest.json.next`（新清单，temp+fsync+rename）
2. 若 target 存在：`rename(target → trash/tree)`、`rename(旧清单 → trash/manifest.json)`
3. `rename(.next → <target>.manifest.json)`
4. `rename(staging/tree → target)`（跨设备 `EXDEV` 直接报错，不复制）
5. 原子写账本
6. 删 trash、删 pending、删 staging

被 `kill -9` 打断在任何一步之后的状态都被 `tests/kill.test.mjs` 真实注入过（`HANAMESH_PROVISION_KILL_AT=<checkpoint>`）：rename 之前 → target 是旧版或不存在，绝无半棵树，`verify` 把 trash 里的旧版放回；rename 之后账本之前 → 磁盘领先账本，`verify` 按清单重算摘要后补账本。账本永远不会声称磁盘上没有的东西（`consistency.json` 的 boundary，安全侧 = target；顺序反转变异会让 X03 变红）。

`remove` 只认 `<target>.manifest.json`：清单没有的文件一律不碰，空目录才删；清单缺失时拒绝删除任何东西。

## 续传与换源

- https 下载写 `<archive>.part` + `.part.json`（去掉 query 的 URL、etag、总长）。重跑时对同一 URL 发 `Range: bytes=<n>-`（带 `If-Range`）；服务端回 200 就从头，416 就丢弃 `.part`。传输失败（断连、5xx）保留 `.part`；摘要不符则删文件、换下一个源；所有源都不行才报错（`E_SHA256` / `E_DOWNLOAD`）。
- `file:` 源直接复制（离线介质）。
- 进度事件 `{item, phase, bytes?, total?, source?, note?}`；日志与错误信息里的 URL 一律去掉 query / 凭据。

## 安全边界

- 只接受 `https:` 与 `file:`；不跟随到非 https 的重定向（最多 10 跳）。
- 解压：拒绝绝对路径、盘符、`..`、NUL；symlink 目标必须解析在树内；拒绝穿过已建 symlink 写文件；tar 只接受普通文件/目录/symlink/hardlink（hardlink 只能指向本 archive 里已解出的文件）；zip 校验 CRC32，只支持 store/deflate，拒绝加密条目。
- 下载内容永不执行，除 `verify.exec` 指定、且 archive 已过 sha256 的那个文件。
- 不读 PATH 上的任何东西（`tests/platform.test.mjs` 锁死源码里没有按名 spawn `node`/`npm`/`python`、没有读 `process.env.PATH`）。

## Windows

所有对外返回的路径经过 `externalPath()`：绝对、规范化、**去掉 `\\?\` / `\\?\UNC\` 前缀**（clawso 教训：带前缀的路径进 PATH 会被命令搜索忽略）。`stripVerbatimPrefix` / `toVerbatimPath` 导出供壳层使用。zip 在 Windows 上没有可执行位这一说，`mode` 记录但不 chmod。真实 Windows 未跑（P07 PLAT NOT_RUN）。

## 耐久性说明

原子性针对的是**进程终止**（CONSISTENCY.md X02/X03 的级别）。解压时不做逐文件 fsync（Node 树 4500 文件在 APFS 上要 20 s+），清单、账本、目录 rename 都 fsync。整机断电后若树内文件损坏，`verify` 通过清单里的逐文件 sha256 报 `corrupt`，用 `install --force` 重装即可。

## 开发

```sh
export npm_config_cache=$(mktemp -d)
npm ci
npm test                 # tsc + node --test --test-reporter=tap tests/*.test.mjs（含真实 SIGKILL 注入）
npm run test:types       # tests/types/consumer.ts 用 TS 5.9 严格模式消费 lib/index.d.ts
npm run test:mutation    # scripts/mutations.mjs：6 条变异，输出到 docs/acceptance/mutations/
npm run check:consistency
node scripts/acceptance-real.mjs p01|p02   # 真实网络（nodejs.org）
```

测试 fixture（`tests/fixtures/https-fixture.mjs`）是本地 HTTPS 服务器（自签证书 `fixture-cert.pem`，测试进程内用 `tls.setDefaultCACertificates` 信任，子进程用 `NODE_EXTRA_CA_CERTS`），支持 Range、可注入错文件 / 断连 / 5xx / 重定向 / 慢速。
