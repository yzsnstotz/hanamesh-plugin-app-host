# 分发与第三方记录

`@hanamesh/lib-provision` 0.2.1 没有运行时依赖。tar / zip 读取、CRC32、sha256、HTTP 下载全部基于 Node.js 内置模块（`zlib`、`crypto`、`fs`、`fetch`）。

本记录按名称、版本、协议、来源、用途列明真实输入。自有代码的协议栏记录已有分发授权，不新增 SPDX 许可或再许可权利；原文见包内 `LICENSE`。

| 名称 | 版本 | 协议 / 依据 | 来源 | 用途 |
|---|---|---|---|---|
| @hanamesh/lib-provision | 0.2.1 | HanaMesh 自有代码分发授权 D-2026-10-05-02（非 SPDX；未指定新许可） | https://github.com/yzsnstotz/hanamesh-lib-provision（Git 范围 `#semver:^0.2.1`）；业务输入 e8707089409ffd3483fc4c964d6032c370dae634 / rc.3，经 ac2896c1fad2fd0373d80e6a9b2ab6833f79251a / rc.4 | Node 库与 hanamesh-provision CLI 的校验、解包、原子提升及账本 |
| @hanamesh/devkit | 0.2.0 | SEE LICENSE IN LICENSE；HanaMesh 自有工具分发授权 D-2026-10-05-02 / D-2026-10-05-16；未指定新标准许可或再许可权利，原文见安装包内 LICENSE 与 LICENSE_RECORD.md | https://github.com/yzsnstotz/hanamesh-server-shared；Git 范围 `#semver:^0.2.0&path:/packages/devkit`，锁定 tag v0.2.0 → 8f9bcc69cbacf01d97ffe63bbbade4f865e6dd89（CONTRACT-DEVKIT-GIT-SUPPLY-01） | 开发与包门工具（check-toolchain / preflight / mutations / verify-pack）；不随包分发，不是 peer |
| typescript | 5.9.3 | Apache-2.0（安装包 LICENSE.txt 原文） | https://registry.npmjs.org/typescript/-/typescript-5.9.3.tgz | 构建 lib/ 与 .d.ts；不随包分发 |
| @types/node | 22.19.7 | MIT（安装包 LICENSE 原文） | https://registry.npmjs.org/@types/node/-/node-22.19.7.tgz | 类型声明；不随包分发 |
| undici-types | 6.21.0 | MIT（安装包 LICENSE 原文） | https://registry.npmjs.org/undici-types/-/undici-types-6.21.0.tgz | @types/node 的锁定传递类型依赖；不随包分发 |

第三方类型与编译工具的协议和锁定来源保留不变。devkit 0.2.0 的四个工具与 rc.2 字节相同，private=false、SEE LICENSE IN LICENSE 不变；不将该授权扩展为 MIT 或其他再许可。旧 devkit rc.1 / rc.2 vendor 归档保全于 Git 历史，不同版替换。

测试 fixture 的自签证书（`tests/fixtures/fixture-cert.pem` / `fixture-key.pem`）由本仓生成，仅供本地 HTTPS fixture 使用，不随包分发。
