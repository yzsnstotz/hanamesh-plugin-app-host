// Supply-contract checks shared by the provider tests and installed consumers. Node built-ins only.
import {spawnSync} from 'node:child_process';
import {readFileSync} from 'node:fs';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';

export const schema = JSON.parse(readFileSync(new URL('./lib-provision.schema.json', import.meta.url), 'utf8'));
export const providerFixture = JSON.parse(readFileSync(new URL('./fixtures/provider.json', import.meta.url), 'utf8'));
export const consumerFixture = JSON.parse(readFileSync(new URL('./fixtures/consumer.json', import.meta.url), 'utf8'));

// Validates the subset of JSON Schema the contract file uses: $ref, type, const, pattern, minLength,
// minimum, required, additionalProperties, properties, items, uniqueItems.
function check(node, value, at, errors) {
  if (node.$ref !== undefined) return check(schema.$defs[node.$ref.split('/').at(-1)], value, at, errors);
  if ('const' in node && JSON.stringify(value) !== JSON.stringify(node.const)) errors.push(`${at}: must be ${JSON.stringify(node.const)}`);
  const type = Array.isArray(value) ? 'array' : value === null ? 'null' : Number.isInteger(value) ? 'integer' : typeof value;
  if (node.type !== undefined && node.type !== type) return errors.push(`${at}: must be ${node.type}`);
  if (node.pattern !== undefined && !new RegExp(node.pattern, 'u').test(value)) errors.push(`${at}: must match ${node.pattern}`);
  if (node.minLength !== undefined && value.length < node.minLength) errors.push(`${at}: too short`);
  if (node.minimum !== undefined && value < node.minimum) errors.push(`${at}: below ${node.minimum}`);
  if (type === 'array') {
    if (node.uniqueItems && new Set(value).size !== value.length) errors.push(`${at}: items must be unique`);
    if (node.items !== undefined) value.forEach((v, i) => check(node.items, v, `${at}[${i}]`, errors));
  }
  if (type === 'object') {
    for (const key of node.required ?? []) if (!(key in value)) errors.push(`${at}.${key}: required`);
    for (const [key, v] of Object.entries(value)) {
      const sub = node.properties?.[key] ?? node.additionalProperties;
      if (sub === false) errors.push(`${at}.${key}: not allowed`);
      else if (sub !== undefined && sub !== true) check(sub, v, `${at}.${key}`, errors);
    }
  }
  return errors;
}

export function validate(kind, value) {
  return check(schema.$defs[kind], value, kind, []);
}

const major = version => Number(version.split('.')[0]);
const missing = (need, have) => need.filter(name => !have.includes(name));

// Only the major is a compatibility boundary; which minor gets installed is the package manager's range.
export function checkSupply(provider, requirement) {
  const errors = [...validate('provider', provider), ...validate('requirement', requirement)];
  if (errors.length > 0) return errors;
  if (provider.package !== requirement.package) errors.push(`package ${provider.package} is not ${requirement.package}`);
  if (major(provider.version) !== requirement.major) errors.push(`major ${major(provider.version)} of ${provider.version} is not required major ${requirement.major}`);
  if (provider.source.tag !== `v${provider.version}`) errors.push(`tag ${provider.source.tag} does not name version ${provider.version}`);
  if (provider.manifestSchema !== requirement.manifestSchema) errors.push(`manifest schema ${provider.manifestSchema} is not ${requirement.manifestSchema}`);
  for (const name of missing(requirement.api, provider.api)) errors.push(`api ${name} missing`);
  for (const name of missing(requirement.bin, Object.keys(provider.bin))) errors.push(`bin ${name} missing`);
  for (const name of missing(requirement.cli, provider.cli)) errors.push(`cli command ${name} missing`);
  return errors;
}

// Reads what an installed (or built) package directory actually provides.
export async function describeInstalled(dir) {
  const pkg = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8'));
  const mod = await import(pathToFileURL(join(dir, pkg.exports['.'].import)).href);
  const api = Object.keys(mod).sort();
  const accepts = schemaNumber => {
    try { mod.validateManifest({schema: schemaNumber, sources: [], items: []}); return true; } catch { return false; }
  };
  const manifestSchema = [1, 2].filter(accepts);
  const usage = spawnSync(process.execPath, [join(dir, pkg.bin['hanamesh-provision']), 'help'], {env: {}, encoding: 'utf8'});
  if (usage.status !== 0) throw new Error(`hanamesh-provision help exited ${usage.status}: ${usage.stderr}`);
  const cli = [...usage.stdout.matchAll(/^ {2}hanamesh-provision (\w+)/gmu)].map(m => m[1]).sort();
  return {
    package: pkg.name,
    version: pkg.version,
    source: {git: providerFixture.source.git, tag: `v${pkg.version}`},
    exports: Object.keys(pkg.exports).sort(),
    bin: pkg.bin,
    api,
    cli,
    manifestSchema: manifestSchema.length === 1 ? manifestSchema[0] : manifestSchema,
    runtimeDependencies: Object.keys(pkg.dependencies ?? {}).length,
  };
}
