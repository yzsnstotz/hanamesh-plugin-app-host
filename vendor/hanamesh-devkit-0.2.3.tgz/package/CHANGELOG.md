- 0.2.0: installable from the hanamesh-server-shared Git source by tag range (pnpm `#semver:^0.2.0&path:/packages/devkit`); adds the `./contract` supply schema, provider/consumer fixtures and suite. Tools, CLI and module policy unchanged.

0.2.2: Same mature tools/CLI/supply schema; paired shared Git-consumer closure and complete shared-pack Devkit files, with updated release metadata.

0.2.2: Paired root source-selector metadata correction; unchanged tool engines and CLI.

0.2.3: Fix verifyPack consumer mode: strict peer validation, no implicit peers, and a frozen-lock reinstall with unchanged lock digest before probes. Metadata-only mode and function inputs/return shape stay unchanged.
