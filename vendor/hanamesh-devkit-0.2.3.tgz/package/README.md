# @hanamesh/devkit

HanaMesh-owned development tooling from `hanamesh-server-shared`. No runtime or third-party dependencies. Distribution is authorized as recorded in LICENSE and LICENSE_RECORD.md; this does not add a standard license or authorize npm publication. Do not publish to npm or add a private registry.

## Install from the Git source

Tags in this repository are repository-wide (`vX.Y.Z`); the root `@hanamesh/server-shared` and this package both carry the tag version. Install with a tag range and the package subdirectory:

```sh
pnpm add -D '@hanamesh/devkit@git+https://github.com/yzsnstotz/hanamesh-server-shared.git#semver:^0.2.0&path:/packages/devkit'
```

| Package manager | Result |
| --- | --- |
| pnpm 10.33.0 | Supported. The lock records `{commit, path: /packages/devkit, repo, type: git}`; `--frozen-lockfile` reinstalls that commit. Installed files follow `files`. |
| npm 11.8.0 | **Not supported.** npm Git specifiers have no subdirectory selector; npm resolves, prepares and installs the root `@hanamesh/server-shared` instead. Do not alias the root package as devkit. |

Range boundary: for 0.x a caret fixes the minor, so `^0.2.0` means `>=0.2.0 <0.3.0`; a 0.3.0 release needs a consumer range change. Prereleases match only when the range names a prerelease of the same `major.minor.patch`. Tags below `v0.2.0` (`v0.1.0-rc.1`, `v0.1.0-rc.2`) predate this package.

The supply contract ships in `./contract`: `schema.json` (`hanamesh.devkit-supply/1`; its major is independent of the package SemVer), `fixtures/provider.json`, `fixtures/consumer.json`, and the suite (`checkProvider`, `checkConsumer`, `validateDescriptor`, `satisfiesCaret`). A consumer verifies its own install with:

```js
import {checkConsumer} from '@hanamesh/devkit/contract';
import requirement from '@hanamesh/devkit/contract/fixtures/consumer.json' with {type: 'json'};
checkConsumer({consumerRoot: process.cwd(), requirement});
```

It resolves and imports every required export from the consumer root, rejects the root package, checks the version against the range, runs the installed `hanamesh-devkit` CLI and reads the commit/path pinned in `pnpm-lock.yaml`.

## Tools

The public ESM exports are `checkToolchain`, `preflight`, `runMutations` and `verifyPack`, also available at their named subpaths. `hanamesh-devkit <command> [devkit.config.mjs]` loads the matching key from the default config export. A config owns module-specific assertions, mutation targets, public API probes and exact versions. The tooling owns execution, assertions, evidence and cleanup.

```js
export default {
  'check-toolchain': {root: process.cwd(), pins: {node:'24.13.1', pnpm:'10.33.0', typescript:'5.9.3'}},
  preflight: {root: process.cwd(), validate: async root => { /* module policy */ }},
  mutations: {root: process.cwd(), cases: [{id:'guard', file:'dist/service.js', test:'test/service.test.mjs', from:'if (allowed)', to:'if (true)'}]},
  'verify-pack': {root: process.cwd(), tarball:'artifacts/module.tgz', required:['dist/index.js']}
};
```

`runMutations` first runs an unmodified baseline, then changes one isolated copy per case, emits explicit TAP, and requires a failing assertion (`not ok` and `ERR_ASSERTION`). Cases accept exact `from`/`to` or a module-owned `mutate` function. Original source/dist stays unchanged. Evidence includes baseline, each mutant and `results.json`; temporary copies are removed even on failure. `nodeArgs` supports TS loaders; `tests` supports multiple suites. Use `temporaryRoot` and `evidenceDir` under the card run directory.

`preflight` rejects engine copies at conventional `scripts/` and `tools/` filenames; thin public-entry wrappers remain allowed. Domain validation is supplied by the module. This source guard does not detect renamed or semantically disguised copies, and is not a replacement for review.

`verifyPack` checks digest (when supplied), required/forbidden entries and a module-owned archive validator. Its optional `consumer` accepts a package manifest, JavaScript public-API probe and TypeScript probe. These run in a temporary install directory with only the tarball and its declared peers; no source-tree resolver or symlink is used. Only explicitly supplied peers are installed. Fresh installation uses strict peer checks; a strict frozen-lock reinstall must retain the generated lock digest before the public probes execute. Missing/incompatible peers, installation, frozen-lock and typechecking errors propagate, and temporary installs are removed. Metadata-only checks do not install anything. The function inputs and returned `{sha256, entries}` remain unchanged.

Runtime errors are **not** exported from this development package. Use `ServerError` from the separate runtime entry `@hanamesh/server-shared/errors` (exact runtime peer + vendored development install in the consuming origin). Shared's existing `SharedError`/`fail`/`safeError` behavior stays intact. Each module retains its code union, status/message mapping, subclass name and serialization. Adopting the runtime base changes runtime bytes and needs its own consumer card/version bump.

Historical compatibility reproduction for frozen Claim/Semantic commits remains in the repository script `scripts/devkit-compatibility.py` and the original card evidence. It is not a current installation route and is excluded from the normal shared package. Current consumers use the normal Git tag range above.
