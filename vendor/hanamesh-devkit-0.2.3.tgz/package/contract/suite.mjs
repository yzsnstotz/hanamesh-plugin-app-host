import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {existsSync, mkdtempSync, mkdirSync, readFileSync, realpathSync, rmSync, writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {dirname, join, relative, resolve, sep} from 'node:path';
import {fileURLToPath} from 'node:url';

// Shape checks mirror contract/schema.json; zero dependencies, so no JSON Schema engine is loaded.
const SCHEMA = 'hanamesh.devkit-supply/1';
const SEMVER = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$/u;
const CARET = /^\^(\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?)$/u;
const readJson = file => JSON.parse(readFileSync(file, 'utf8'));
const object = (value, label) => assert.ok(value && typeof value === 'object' && !Array.isArray(value), `${label} must be an object`);

function exportMap(map, label) {
  object(map, label);
  assert.ok(Object.keys(map).length > 0, `${label} empty`);
  for (const [subpath, names] of Object.entries(map)) {
    assert.match(subpath, /^\.(?:\/[a-z-]+)*$/u, `${label} subpath ${subpath}`);
    assert.ok(Array.isArray(names) && names.every(name => /^[A-Za-z]\w*$/u.test(name)), `${label} ${subpath} names`);
  }
}

export function validateDescriptor(value) {
  object(value, 'descriptor');
  assert.equal(value.schema, SCHEMA, 'SUPPLY_SCHEMA');
  if (value.kind === 'consumer') {
    assert.deepEqual(Object.keys(value).sort(), ['bin', 'exports', 'kind', 'manager', 'notPackage', 'package', 'range', 'schema']);
    assert.equal(value.package, '@hanamesh/devkit');
    assert.match(value.range, CARET, 'SUPPLY_RANGE_UNSUPPORTED only ^X.Y.Z[-pre] is defined');
    assert.equal(value.manager, 'pnpm', 'SUPPLY_MANAGER_UNSUPPORTED');
    exportMap(value.exports, 'consumer exports');
    assert.equal(typeof value.bin, 'string');
    assert.equal(value.notPackage, '@hanamesh/server-shared');
    return value;
  }
  assert.equal(value.kind, 'provider', 'SUPPLY_KIND');
  assert.deepEqual(Object.keys(value).sort(), ['bin', 'dependencies', 'exports', 'files', 'install', 'kind', 'package', 'peerDependencies', 'range', 'schema', 'source']);
  assert.equal(value.package.name, '@hanamesh/devkit');
  assert.match(value.package.version, SEMVER);
  assert.match(value.source.repository, /^https:\/\/github\.com\/yzsnstotz\/hanamesh-server-shared\.git$/u);
  assert.equal(value.source.path, '/packages/devkit');
  assert.equal(value.source.tag, `v${value.package.version}`, 'SUPPLY_TAG_VERSION tag must name the package version');
  assert.equal(typeof value.source.tagNamespace, 'string');
  exportMap(value.exports, 'provider exports');
  object(value.bin, 'bin');
  assert.ok(Array.isArray(value.files) && value.files.length > 0);
  assert.equal(Object.keys(value.dependencies).length, 0, 'SUPPLY_RUNTIME_DEPENDENCY');
  assert.equal(Object.keys(value.peerDependencies).length, 0, 'SUPPLY_PEER_DEPENDENCY');
  for (const manager of ['pnpm', 'npm']) {
    const entry = value.install[manager];
    object(entry, `install.${manager}`);
    assert.equal(typeof entry.supported, 'boolean');
    assert.match(entry.tested, SEMVER);
    if (entry.supported) {
      assert.equal(typeof entry.lockResolution, 'string');
      assert.ok(entry.specifier.endsWith(`#semver:${value.range.specifier}&path:${value.source.path}`), `SUPPLY_SPECIFIER ${manager}`);
      assert.ok(entry.specifier.startsWith(`git+${value.source.repository}`), `SUPPLY_SPECIFIER ${manager}`);
    } else assert.equal(typeof entry.reason, 'string', `install.${manager}.reason`);
  }
  assert.match(value.range.specifier, /^\^\d+\.\d+\.\d+$/u);
  assert.ok(satisfiesCaret(value.package.version, value.range.specifier), 'SUPPLY_RANGE_EXCLUDES_VERSION');
  return value;
}

function parse(version) {
  const match = SEMVER.exec(version);
  assert.ok(match, `SUPPLY_VERSION_INVALID ${version}`);
  return {tuple: match.slice(1, 4).map(Number), pre: match[4]?.split('.') ?? []};
}

function compare(a, b) {
  for (let index = 0; index < 3; index++) if (a.tuple[index] !== b.tuple[index]) return a.tuple[index] - b.tuple[index];
  if (!a.pre.length || !b.pre.length) return b.pre.length - a.pre.length;
  for (let index = 0; index < Math.max(a.pre.length, b.pre.length); index++) {
    const [x, y] = [a.pre[index], b.pre[index]];
    if (x === undefined || y === undefined) return x === undefined ? -1 : 1;
    if (x === y) continue;
    const [nx, ny] = [/^\d+$/u.test(x), /^\d+$/u.test(y)];
    if (nx && ny) return Number(x) - Number(y);
    if (nx !== ny) return nx ? -1 : 1;
    return x < y ? -1 : 1;
  }
  return 0;
}

// Caret semantics of node-semver/pnpm for ^X.Y.Z[-pre]; any other range syntax is rejected, not approximated.
export function satisfiesCaret(version, range) {
  const match = CARET.exec(range);
  assert.ok(match, `SUPPLY_RANGE_UNSUPPORTED ${range}`);
  const low = parse(match[1]), actual = parse(version);
  const [major, minor, patch] = low.tuple;
  const high = major > 0 ? [major + 1, 0, 0] : minor > 0 ? [0, minor + 1, 0] : [0, 0, patch + 1];
  if (actual.pre.length && !(low.pre.length && actual.tuple.every((part, index) => part === low.tuple[index]))) return false;
  return compare(actual, low) >= 0 && compare(actual, {tuple: high, pre: ['0']}) < 0;
}

// Real CLI call: a clean root passes preflight, a copied runner is rejected by the installed tool.
function exerciseCli(command) {
  const root = mkdtempSync(join(tmpdir(), 'devkit-supply-cli-'));
  try {
    writeFileSync(join(root, 'devkit.config.mjs'), `export default {preflight: {root: ${JSON.stringify(root)}}};\n`);
    const clean = spawnSync(command[0], [...command.slice(1), 'preflight', join(root, 'devkit.config.mjs')], {cwd: root, encoding: 'utf8'});
    assert.equal(clean.status, 0, `SUPPLY_CLI_FAILED ${clean.stderr}`);
    mkdirSync(join(root, 'scripts'));
    writeFileSync(join(root, 'scripts/mutations.mjs'), "import {spawnSync} from 'node:child_process';\nfor (const m of []) spawnSync(m);\n");
    const copied = spawnSync(command[0], [...command.slice(1), 'preflight', join(root, 'devkit.config.mjs')], {cwd: root, encoding: 'utf8'});
    assert.notEqual(copied.status, 0, 'SUPPLY_CLI_ACCEPTED_COPY');
    assert.match(copied.stderr, /DUPLICATE_DEVKIT_TOOL scripts\/mutations\.mjs/u);
    return {clean: clean.status, copied: copied.status};
  } finally { rmSync(root, {recursive: true, force: true}); }
}

// Resolves and imports from a separate Node process rooted at `cwd`, as the consumer itself would.
function probe(cwd, name, exportsMap) {
  const script = `const out = {};
for (const [sub, names] of Object.entries(${JSON.stringify(exportsMap)})) {
  const id = sub === '.' ? ${JSON.stringify(name)} : ${JSON.stringify(name)} + sub.slice(1);
  const mod = await import(id);
  out[sub] = {url: import.meta.resolve(id), types: Object.fromEntries(names.map(n => [n, typeof mod[n]]))};
}
console.log(JSON.stringify(out));`;
  const run = spawnSync(process.execPath, ['--input-type=module', '-e', script], {cwd, encoding: 'utf8'});
  assert.equal(run.status, 0, `SUPPLY_RESOLVE_FAILED ${run.stderr}`);
  return JSON.parse(run.stdout);
}

function assertExports(found, exportsMap, packageRoot) {
  for (const [subpath, names] of Object.entries(exportsMap)) {
    const file = realpathSync(fileURLToPath(found[subpath].url));
    assert.ok(!relative(packageRoot, file).startsWith('..') && !relative(packageRoot, file).startsWith(sep), `SUPPLY_EXPORT_OUTSIDE_PACKAGE ${subpath}`);
    for (const name of names) assert.equal(found[subpath].types[name], 'function', `SUPPLY_EXPORT_MISSING ${subpath} ${name}`);
  }
}

export function checkProvider({packageRoot, descriptor}) {
  validateDescriptor(descriptor);
  assert.equal(descriptor.kind, 'provider');
  const root = realpathSync(resolve(packageRoot));
  const pkg = readJson(join(root, 'package.json'));
  assert.equal(pkg.name, descriptor.package.name, 'SUPPLY_NAME');
  assert.equal(pkg.version, descriptor.package.version, 'SUPPLY_VERSION');
  const moduleExports = Object.keys(pkg.exports).filter(key => String(pkg.exports[key]).endsWith('.mjs')).sort();
  assert.deepEqual(moduleExports, Object.keys(descriptor.exports).sort(), 'SUPPLY_EXPORT_SET');
  assert.deepEqual(pkg.bin, descriptor.bin, 'SUPPLY_BIN');
  assert.deepEqual([...pkg.files].sort(), [...descriptor.files].sort(), 'SUPPLY_FILES');
  assert.equal(Object.keys(pkg.dependencies ?? {}).length, 0, 'SUPPLY_RUNTIME_DEPENDENCY');
  assert.equal(Object.keys(pkg.peerDependencies ?? {}).length, 0, 'SUPPLY_PEER_DEPENDENCY');
  const found = probe(root, pkg.name, descriptor.exports);
  assertExports(found, descriptor.exports, root);
  const [bin] = Object.values(pkg.bin);
  const cli = exerciseCli([process.execPath, join(root, bin)]);
  return {name: pkg.name, version: pkg.version, packageRoot: root, exports: Object.keys(found), cli};
}

export function checkConsumer({consumerRoot, requirement}) {
  validateDescriptor(requirement);
  assert.equal(requirement.kind, 'consumer');
  const root = realpathSync(resolve(consumerRoot));
  const found = probe(root, requirement.package, requirement.exports);
  let packageRoot = dirname(realpathSync(fileURLToPath(found['.'].url)));
  while (!existsSync(join(packageRoot, 'package.json'))) {
    assert.notEqual(dirname(packageRoot), packageRoot, 'SUPPLY_PACKAGE_ROOT_NOT_FOUND');
    packageRoot = dirname(packageRoot);
  }
  const pkg = readJson(join(packageRoot, 'package.json'));
  assert.notEqual(pkg.name, requirement.notPackage, 'SUPPLY_ROOT_PACKAGE_INSTALLED');
  assert.equal(pkg.name, requirement.package, 'SUPPLY_NAME');
  assert.ok(satisfiesCaret(pkg.version, requirement.range), `SUPPLY_RANGE ${pkg.version} !~ ${requirement.range}`);
  assertExports(found, requirement.exports, packageRoot);
  const bin = join(root, 'node_modules', '.bin', requirement.bin);
  assert.ok(existsSync(bin), `SUPPLY_BIN_MISSING ${requirement.bin}`);
  const cli = exerciseCli([bin]);
  const lock = readFileSync(join(root, 'pnpm-lock.yaml'), 'utf8');
  const resolution = /'?@hanamesh\/devkit@[^\n]*:\n\s+resolution: \{commit: ([0-9a-f]{40}), path: (\/packages\/devkit), repo: ([^,]+), type: git\}/u.exec(lock);
  assert.ok(resolution, 'SUPPLY_LOCK_RESOLUTION pnpm-lock.yaml must pin commit + /packages/devkit');
  return {name: pkg.name, version: pkg.version, packageRoot, commit: resolution[1], path: resolution[2], repo: resolution[3], exports: Object.keys(found), cli};
}
