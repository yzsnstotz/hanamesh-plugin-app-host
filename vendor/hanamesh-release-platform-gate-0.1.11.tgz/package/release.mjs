#!/usr/bin/env node
import {execFileSync} from 'node:child_process';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {createHash} from 'node:crypto';
import {checkRelease,GateError,INVARIANT,REASON,DEPENDENCY_SHAPE_CONTRACT,PLATFORM_CLOSURE_CONTRACT} from './index.mjs';
// The only publisher entry: pack normally, check that immutable artifact,
// then publish precisely that tarball. Running check never publishes.
let receiptDirectory;
try {
 const [action,...args]=process.argv.slice(2);
 if(action==='source-guard')throw new GateError([{code:'SOURCE_PUBLISH_FORBIDDEN',package:'release',path:'prepublishOnly',detail:'Directory publishing is blocked. Use npm run release:publish to check and publish the exact normal tarball; this invariant has no disable switch.'}]);
 if(!['check','publish'].includes(action))throw new GateError([{code:'ARGUMENT_INVALID',package:'release',path:'arguments',detail:'use check|publish --lockfile PATH'}]);
 const flags={'--lockfile':'lockfile','--source-root':'sourceRoot','--outdir':'outdir','--artifact-cache':'artifactCache'},opt={};
 for(let i=0;i<args.length;i+=2){const key=flags[args[i]];if(!key||!args[i+1]||args[i+1].startsWith('--')||Object.hasOwn(opt,key))throw new GateError([{code:'ARGUMENT_INVALID',package:'release',path:'arguments',detail:'invalid option; no disable switch'}]);opt[key]=args[i+1];}
 if(!opt.lockfile)throw new GateError([{code:'ARGUMENT_INVALID',package:'release',path:'arguments',detail:'explicit frozen lockfile required'}]);
 const outdir=resolve(opt.outdir??'artifacts/release-platform');receiptDirectory=outdir;await mkdir(outdir,{recursive:true});
 await writeFile(resolve(outdir,'.run-state.json'),JSON.stringify({owner:'release-platform-gate',keep:false,state:'active'})+'\n');
 // Run npm's JS entry with Node on every OS; spawning npm.cmd directly with
 // shell:false fails on Windows, and a shell would misinterpret spaced paths.
 const npm=process.env.npm_execpath??resolve(dirname(process.execPath),process.platform==='win32'?'node_modules/npm/bin/npm-cli.js':'../lib/node_modules/npm/bin/npm-cli.js');
 if(!npm.endsWith('npm-cli.js'))throw new GateError([{code:'ARGUMENT_INVALID',package:'release',path:'npm entry',detail:'use npm run release:check/publish with the normal npm CLI'}]);
 const packed=JSON.parse(execFileSync(process.execPath,[npm,'pack','--json','--ignore-scripts=false','--pack-destination',outdir],{encoding:'utf8',shell:false}));
 if(!Array.isArray(packed)||packed.length!==1||typeof packed[0].filename!=='string')throw Error('PACK_RESULT_INVALID');
 const artifact=resolve(outdir,packed[0].filename);if(dirname(artifact)!==outdir)throw Error('PACK_PATH_INVALID');
 const result={...await checkRelease({...opt,tarball:artifact}),artifact};
 await writeFile(resolve(outdir,'receipt.json'),JSON.stringify(result,null,2)+'\n');
 if(action==='publish'){
   const sha=createHash('sha256').update(await readFile(artifact)).digest('hex');
   if(sha!==result.tarballSHA256)throw new GateError([{code:'INTEGRITY_MISMATCH',package:result.package,path:artifact,detail:'checked tarball changed before publish'}]);
   // There is deliberately no source-directory publish or second pack here.
   execFileSync(process.execPath,[npm,'publish',artifact],{stdio:['ignore','inherit','inherit'],shell:false});
 }
 await writeFile(resolve(outdir,'.run-state.json'),JSON.stringify({owner:'release-platform-gate',keep:false,state:'complete'})+'\n');
 process.stdout.write(JSON.stringify(result)+'\n');
} catch(error) {
 const failure={platformClosureContract:PLATFORM_CLOSURE_CONTRACT,dependencyShapeContract:DEPENDENCY_SHAPE_CONTRACT,invariant:INVARIANT,disableable:false,reason:REASON,status:'FAIL',findings:error instanceof GateError?error.findings:[{code:'RELEASE_CHECK_FAILED',package:'release',path:'normal pack/check',detail:'normal pack or evidence processing failed ('+(error.code??error.status??error.name)+'); no fallback'}]};
 if(receiptDirectory){await writeFile(resolve(receiptDirectory,'receipt.json'),JSON.stringify(failure,null,2)+'\n');await writeFile(resolve(receiptDirectory,'.run-state.json'),JSON.stringify({owner:'release-platform-gate',keep:false,state:'failed'})+'\n');}
 process.stdout.write(JSON.stringify(failure)+'\n');process.exitCode=1;
}
