# 支持的依赖形态合同 dependency-shapes-v1（0.1.11；平台审查扩展 optional-platform-paths-v1）

这是 R2 的审查边界：合同内的形态必须准确遍历且不误拒；合同外的解析形态必须返回 `UNSUPPORTED_DEPENDENCY_SHAPE`，含 `package/path/shape/why/action/contract`。每次检查输出均携带 `dependencyShapeContract`。正常 `release check` 的失败也写入 receipt.json；发布说明公开同一边界。不得猜测、忽略未知解析字段、回退另一份源码、放行或关闭检查。扩展合同须另立红例、实现并独审；本候选独审前不得接线。

## 输入与判定层次

输入是正常 npm pack 生成的真实归档和对应冻结锁，根为 package/package.json。以实际工件内容和冻结图为证据，不读取宿主 node_modules 代替。检查生产/optional/必需 peer、已绑定 optional peer、自动 npm workspace、全部实际安装 bundle 及每个实际包自身的锁；与这些边不可达的开发包不属于安装闭包。只用于绑定必需 peer 的开发锁节点仍进入闭包。absent optional peer 记录其缺席，不自动安装。锁内声明和实际清单声明均保留，不能互相覆盖真正生效的限制。

支持的形态不保证 PASS：必需路径的 os/cpu/libc 字段仍是 PLATFORM_FIELD；平台名称 optional 目标缺冻结绑定仍是 PLATFORM_OPTIONAL；完整可选子图按下节检查；缺文件/绑定/强 SRI 是 CLOSURE_UNPROVEN；具体版本/身份/路径漂移是 LOCK_DRIFT；字节不符是 INTEGRITY_MISMATCH；损坏 JSON/YAML、缺必需结构是 LOCK_INVALID / EVIDENCE_INVALID；不安全或损坏归档是 ARCHIVE_INVALID。这些是合同内证据或不变量不满足，不能改成通过。遇多个问题按实际遍历首次失败返回，不承诺一次穷举所有问题。

清单依赖控制字段是 dependencies、optionalDependencies、peerDependencies（名字到非空字符串）、peerDependenciesMeta（仅 optional 布尔）、bundleDependencies/bundledDependencies（两个拼写分别核名字数组或布尔类型，不能用一项遮住另一项的坏类型；合法双项按bundleDependencies优先）、npm workspaces（非空字符串模式数组，或仅含packages模式数组的对象；其他对象键具名拒绝，npm matcher 5.0.3 的匹配/排除语义）。其他普通包描述、scripts、exports 等元数据不产生本门的额外依赖边；本门不运行依赖的安装/prepare 脚本，不验证它们动态下载的内容。清单出现 overrides、resolutions、pnpm、acceptDependencies、dependenciesMeta 即具名拒绝；不模拟解析器改写、注入、patch、catalog、hook 或其他包管理器。

## 白名单准入顺序（所有入口共用）

先核 metadata grammar（字段名、依赖控制字段类型及解析器标志），再对每条**有效安装边**判定声明来源与物理供给策略，最后检查真实清单、平台字段、身份/范围/SRI及后续边。npm根、内层包自身每份锁的新根、普通节点和全部pnpm importer均必须经过相同准入；不能只在node(key)中校验普通节点。自包含bundle的外部边也先判策略再拒缺锁，不能以CLOSURE_UNPROVEN遮住未知来源；未声明但实际存在的node_modules extra也必须准入并记录，不能从旁路直接查包而不分类。

registry/git声明先由固定 `npm-package-arg@13.0.2` 解析并核类型白名单：registry仅version/range/tag及其npm alias，git仅git类型且必须实际bundle。该解析只用于准入，不用其宿主路径归一结果查文件。file/link/workspace及HTTPS是显式分支，未知类型没有默认通过分支；字面协议前缀npm:/file:/link:/workspace:/https:按小写识别，其他大小写变体不在本版语法内并具名拒绝。HTTPS URL语法/匿名策略/冻结URL绑定在bundle分派前同样准入，不能由bundle遮住无效URL、认证URL或冻结位置漂移。npm根已被workspace取代的原字符串不是有效边，以明确的npm-root-workspace策略处理并保留原文；其他子边不得删除原声明范围。

每条遍历边在 `sourceEdges.supportedShape` 写入下表之一；`visitEdge`仅分派已准入策略，default无条件UNSUPPORTED_DEPENDENCY_SHAPE。`type`是当前分类，`declaredType/declaredSpec/effectiveSpec`保留原文及生效约束。真正缺席的optional peer先核声明/元数据grammar，再列absentOptionalPeers，不虚构安装边。

| supportedShape白名单 | 可判断的供给及约束 |
|---|---|
| npm-root-workspace | npm图根实际workspace + 具体冻结link；同名原声明已被取代，effectiveSpec=workspace:* |
| frozen-linked-directory | **根或子边的真实registry semver/alias声明**，冻结图却指向具体本地link/importer；按冻结坐标取同一真实tar内目录，原spec/range/peer/身份保留，不再向registry重建目标 |
| packed-bundle | 实际已打包安装bundle；声明来源仍须准入，不借bundle隐藏未知协议 |
| packed-bundle-extra | 未声明但实际存在的安装bundle；inferredFrom=actual-packed-extra-version，显式核实际/冻结版本与闭包，不声称这是源清单声明 |
| packed-file / packed-link / packed-workspace | 真实tar内本地目录或tar（file）；具体冻结link或强SRI，展开其bundle/vendor及每份自身锁 |
| locked-registry-artifact | 完整冻结registry节点，明确本地锁工件/匿名HTTPS，或明确版本的canonical registry URL + 必需强SRI |
| locked-https-artifact | HTTPS声明与冻结位置精确一致，无认证/query/hash/redirect，强SRI |

没有其他隐式策略；无法分类的声明、解析字段或物理供给一律具名UNSUPPORTED_DEPENDENCY_SHAPE。已分类但缺目标、越界、漂移、无SRI等仍按上文具名证据错误拒绝，不将“已分类”写成PASS。

## 来源八类

| 形态 | 合同内处理 | 合同外或证据不足 |
|---|---|---|
| registry | semver 7.7.2 可解析的完整版本/范围/OR/预发行范围或字母开头的字面 dist-tag；npm:目标包@范围/tag alias。冻结节点定位真实 tar，匿名 HTTPS 或显式本地锁工件，强 SHA256/384/512 SRI；核目标名、实际/锁版本和全部 incoming 范围，递归闭包。 | 非法 alias/未知协议为 UNSUPPORTED；无完整冻结节点/SRI 为 CLOSURE_UNPROVEN；不重新解析 tag，不用 registry 同名包替换 git。 |
| git | npm 锁图中已实际 bundle 的 git/托管简写边可检查真实 bundle 的完整闭包；git 文本只标识来源，不 checkout、不 prepare。 | 未实际 materialize 的 git 为 declaration.git-unmaterialized；pnpm 的 git type/repo/commit resolution 不在本版锁 grammar 内，具名拒绝，不从 registry 猜。 |
| file | file:相对路径及 ./相对 tar；真实归档内的目录或 .tgz/.tar.gz/.tar。目录须具体冻结 link/importer，tar 须强 SRI。目录/tar类型由具体冻结link与实际manifest/archive供给判定，不把.tgz后缀当目录类型证据；目录计划若实际供给tar具名UNSUPPORTED。相对于引用包的真实坐标展开，允许同一归档中兄弟目录；递归 bundle/vendor/自身锁。 | 绝对、越出真实归档、目标缺失/漂移/缺绑定、内层 tar 借外层文件均不满足证据。源树同名文件不是替代物。 |
| link | link:相对目录；具体冻结 npm link 或 pnpm link: importer，实际目录必须在该归档且与目标完全一致；同上递归。 | 不模拟宿主软链/外部路径；实际 tar 中清单软链接为 ARCHIVE_INVALID，缺包为 CLOSURE_UNPROVEN。 |
| tarball | 声明为匿名 HTTPS URL，且与冻结 resolved/tarball 完全一致；无 credentials/query/hash/redirect；缓存仍验来源和强 SRI。本地 tar 归 file/vendor。 | HTTP 为 declaration.http；其他协议为具名 unsupported；HTTPS 的认证/重定向或缺证据仍拒绝，不做网络重试或替代下载。 |
| workspace | npm 根按真实 tar 中 workspaces+实际包名匹配，核冻结具体 link；自动边也检查。npm 根 workspace 优先于同名 deps/optional/peer 原声明，原文留在 sourceEdges，effectiveSpec=workspace:*，原来的版本/alias/未知来源不再生效；真实子包 peer 仍单独校验。真实子semver/alias边绑定具体workspace/link目录时按frozen-linked-directory取真实目录，保持原范围，不做根优先级替换。显式 workspace:* / ^ / ~ / semver 须具体冻结目录，pnpm link importer 同上。 | 缺目标、声明/冻结目标漂移、重复名拒绝；workspace:空/全空白范围或非范围文本具名unsupported。此优先级仅 npm 图根，包括包自身 npm 锁的新图根，不扩展到普通子包或 pnpm。 |
| bundled | 实际 node_modules 下安装包及声明的 bundle 数组/布尔；按实际嵌套 npm 路径或所属 pnpm snapshot 关联，不根回退。无锁节点只允许同一归档内全部安装边完全闭合，单独输出 selfContainedBundles。 | 声明 bundle 缺包或任何外部边缺锁拒绝；不能用 bundle 删除真实 peer/范围/平台字段。 |
| vendor | 无特殊免查地位。被 file/link/锁本地 tar 指向的实际目录/归档，与 bundled 及自身各锁递归；vendor 内未引用且不是安装 bundle 的普通源码不是安装边。 | 不扫描宿主源树补包、不因目录名叫 vendor 而信任，不跨归档边界。 |

## 冻结锁 grammar

- npm JSON **数字 2/3**，packages 表为权威图，必须有根记录。顶层仅 name/version/lockfileVersion/requires/packages/dependencies；v2 的旧 dependencies 镜像不作为另一套解析图。未知顶层字段具名 unsupported。根清单与锁的生产声明、workspaces 核一致。
- npm reachable link 记录仅 link/resolved/dev/optional/devOptional；link必须字面true，resolved为字符串图内具体普通记录，不能链式link；dev/optional/devOptional仅布尔。图根（含内层自身锁根）与普通reachable记录共用字段白名单和字段类型准入；记录允许 name/version/resolved/integrity/dev/devOptional/optional/peer/inBundle/dependencies/optionalDependencies/peerDependencies/peerDependenciesMeta/devDependencies/bin/engines/license/hasInstallScript/hasShrinkwrap/os/cpu/libc/deprecated/funding/bundleDependencies/bundledDependencies/workspaces；同时明确允许以下不改安装边的描述/清单镜像字段：private/main/type/files/scripts/description/exports/types/typings/repository/author/contributors/keywords/homepage/bugs/publishConfig/packageManager（其值只作普通JSON元数据，不推导安装来源）。已知解析改写字段先以manifest.<字段>具名拒绝，其他未知字段以lock.npm.record.<字段>拒绝。name/version/resolved/integrity存在时必须字符串；dev/devOptional/optional/peer/inBundle/hasInstallScript/hasShrinkwrap存在时必须布尔。描述字段不改边；dev 标签不让已进入安装闭包的节点免查。
- pnpm YAML **字符串 9.0**（正常 pnpm 写出的 lockfileVersion: '9.0'；数值 9 不在合同内），仅 lockfileVersion/settings/importers/packages/snapshots。settings 仅 autoInstallPeers=true、excludeLinksFromLockfile=false（可省略）。根 importer 必需；纯 link 图可省略 packages/snapshots，按空表处理。
- pnpm importer 仅 dependencies/optionalDependencies/devDependencies/peerDependencies/peerDependenciesMeta。生产/optional/dev声明结构精确为 {specifier:字符串,version:字符串}；开发边仅在实际需要绑定peer时进入闭包。每个importer的peerDependencies是名字到非空声明字符串，peerDependenciesMeta每项仅optional布尔；injected等未知项具名拒绝，包含根/实际使用的本地importer/其他importer。所有importer结构都预检，不支持混合其他 importer grammar。
- pnpm reachable packages 仅 resolution/name/version/id/engines/cpu/os/libc/hasBin/deprecated/peerDependencies/peerDependenciesMeta/bundledDependencies/bundleDependencies/requiresBuild/optional/dev。resolution仅integrity/tarball且存在时必须字符串，未知 type/repo/commit/directory/patch 等字段具名拒绝。snapshots 仅 dependencies/optionalDependencies/optional/transitivePeerDependencies/peerDependencies/peerDependenciesMeta/id，安装边必须名字到非空引用字符串。packages的name/version/id仅字符串、hasBin/requiresBuild/optional/dev仅布尔；snapshots的id仅字符串、optional仅布尔，transitivePeerDependencies仅字符串数组。
- pnpm 循环 peer 的缩写 context 优先使用同一 snapshot 的有效依赖边（optionalDependencies 优先于 dependencies，与现有 ref 解析一致）中该 peer 的完整冻结目标；目标的 name@version 必须与 context 前缀完全一致。已有显式依赖边缺目标时不得回退缩写或其他节点；无该依赖边时保留原 context 精确查找。完整目标仍须有 snapshot/package metadata，进入原 peer/范围/SRI/平台与完整后续闭包检查，不作豁免。
- pnpm snapshot 的括号 peer context 支持带包名@冻结引用的 scoped、嵌套上下文；每个显式 binding 都要查目标，不能变 absent optional；无名哈希/patch context 不支持并具名拒绝。transitivePeerDependencies 仅描述可提升的 peer 名称，不凭名字构造额外包；真实声明与已冻结 binding 仍完整检查。
- reachable 的未知锁字段具名拒绝。无关 dev 节点字段不进入安装闭包；锁全局解析设置与 importer grammar 仍预检。所有 actual 包内 npm-shrinkwrap.json / package-lock.json / pnpm-lock.yaml 各开独立图，全查；不择一绕开另一份锁。

## 路径、测试及审查边界

固定 npm 11.8.0 / Node24.13.1。普通归档路径按字面大小写、Unicode 和百分号比较，不盲 decodeURIComponent、不 case-fold、不 Unicode normalize。npm root workspace 的来源选择先于原声明路径，故 %20/Unicode/大小写不同的 shadowed 文本可以通过，而实际冻结目标必须精确匹配。软链源如果正常打包后只剩真实 workspace 目标，就查真实目标；缺失 tar 清单不能从源树软链补齐。

范围按 npm 11.8.0 / Arborist 9.1.10 的 registry 入边语义核验：不全局启用 includePrerelease。普通 `^1.0.0`、`>=1.0.0 <2.0.0`、`1.x`、`x`、`>=0.0.0` 不接受 `1.1.0-beta.1`；显式 `^1.1.0-beta.1` 接受同一 major/minor/patch 的符合比较器的预发行，不能据此接受 `1.2.0-beta.1`；OR 各分支保持原语义。npm 对去除首尾空白后的字面 `*` 允许已绑定的预发行目标，该例外不能扩到被 semver 归一成 `*` 的其他原声明。完整有效版本仍必须存在，名称/锁版本/平台字段仍核。alias 的目标范围、prod/optional/peer、真实 workspace 子边、bundle/外取节点共用此检查；npm 根 workspace 优先级保持原合同。npm 只在此使用 loose range 解析，不更改本合同前置的合法清单版本/声明准入边界。未知形态仍按前述具名拒绝，不改变合同外策略。

合同测试入口：test/admission.test.mjs（根/自身锁根/pnpm importer共用准入、RPG-09/10/11、extras、未知native协议、字段类型、真实child range/平台反例）；test/dependency-shapes.test.mjs（workspace覆盖、真实子peer反例、未知协议/版本/扩展字段/设置、正常 release 失败持久回执）；test/source-closure.test.mjs（八类来源、内层锁、SRI）；test/sibling-closure.test.mjs（同归档兄弟闭包）；test/npm-paths.test.mjs（正常 npm 生命周期、编码、Unicode、大小写、软链）；其他原平台/peer/锁/发布测试全部保留。正常 npm install→ci→runtime require→release check 的 R2 原三例必须重新实跑，并只读重放原 tar/锁。四插件当前正式工件与对应锁逐一实测，版本/源码/锁hash/闭包见同次编排交件，不以四仓接线或其他 OS 真机冒充。

R2 范围：合同内零漏查、零误拒；合同外具名 UNSUPPORTED_DEPENDENCY_SHAPE。未知版本/协议/解析扩展的后续支持必须先修改这份版本合同并经审查，不能以合法 npm/pnpm 的无限全集为本版承诺。Windows/Linux 真机、真实发布、四仓接线、DSH安装仍 NOT_RUN。

## 0.1.9 alias规范化与错误分类（RPG-12）

registry alias准入与目标解析统一使用固定 npm-package-arg13.0.2 的 alias/subSpec，目标仅version/range/tag；目标身份取subSpec.name，范围取subSpec.fetchSpec，原声明仍原样保留在sourceEdges。合法范围首尾/内部空白（包括真实Tab/LF/CRLF）按该解析器和semver范围语义处理，scoped alias相同；不手写另一套alias正则。省略范围的 npm:helper 与 npm:helper@ 使用npm的默认*；npm:helper@后仅空白时fetchSpec可能为空字符串，保持npm的范围语义，不以逻辑或兜成*。嵌套alias、alias指向本地/Git或解析器不接受的形式均具名declaration.registry-alias拒绝。锁与实际声明仍逐字核冻结一致，不能替换原声明或忽略真实版本/平台字段。

收尾审查标准：合同内已建模语义必须准确判断；合同外解析形态一律UNSUPPORTED_DEPENDENCY_SHAPE，输出形态/原因/处理建议，不以LOCK_DRIFT或invalid alias隐藏能力限制。具体明确合同外：认证或带query/hash的HTTPS声明为declaration.tarball-url-policy，冻结artifact此类位置为resolution.https-policy；绝对/反斜线file/link归档坐标为declaration.local-target；冻结file工件非显式.tar/.tgz/.tar.gz为resolution.local-artifact；固定npm matcher不能处理的workspace模式为manifest.workspaces-pattern。均使用同一具名输出，缓存和bundle不能绕过。相对路径虽合法但逃出实际归档、缺文件/绑定/强SRI仍是CLOSURE_UNPROVEN；实际身份/版本/范围/路径与冻结证据矛盾才LOCK_DRIFT；损坏语法/必需结构才LOCK_INVALID/ARCHIVE_INVALID，I/O/网络/正常pack失败保留实际处理失败，不伪称未知依赖形态。


## 0.1.11 平台可选路径审查 optional-platform-paths-v1（PK2）

正式语义来源：[npm package.json](https://docs.npmjs.com/cli/v11/configuring-npm/package-json/#optionaldependencies)、[npm os/cpu/libc](https://docs.npmjs.com/cli/v11/configuring-npm/package-json/#os)、[pnpm supportedArchitectures](https://pnpm.io/settings#supportedarchitectures)。optionalDependencies 是允许缺席/安装失败的边，并覆盖同名 dependencies；os/cpu/libc 是安装适用性元数据。pnpm 冻结图可以同时保留所有平台的可选包；仅凭字段存在、平台包名或本机未安装不能断言危险。0.1.10 的无条件拒绝混淆了合法分发元数据与必需路径的不兼容。

本门仍要求跨平台可移植的**必需**闭包；根平台限制一律拒绝。每条遍历路径携带 optionalPath：进入真实 optionalDependencies 边后，其后继必需边仍属于可选子图；有任一必需路径到达的节点必须再次以必需状态检查。循环去重同时包含锁节点/实际清单及路径状态，不能由先前可选访问遮住后来的必需边。已绑定 peer 是真实边；peer 的 optional 标记本身不授予平台豁免。npm/pnpm 的 optional/devOptional 标签不能代替路径证明。

允许可选子图携带 os/cpu/libc 字符串数组（含空数组和 ! 排除 token）；其他类型/无法解释 token 以 manifest.platform-selector 具名 UNSUPPORTED 拒绝，不声称覆盖无限 npm 元数据。审查不按当前 OS/CPU/libc 过滤或丢弃任何节点，不执行安装脚本，不证明动态下载与运行时 fallback。所有可选目标均仍须实际归档、完整冻结闭包、名字/范围/SRI 与来源审查；无冻结绑定的平台名称保留 PLATFORM_OPTIONAL 拒绝，其余缺证据仍 CLOSURE_UNPROVEN。锁内额外边不能借实际清单缺失而逃查，也不能仅凭锁的可选标记豁免平台限制。

PASS/FAIL 都带 platformClosureContract；sourceEdges 和 checked 记录 optionalPath，实际清单的 platformConstraints 原样记录。没有官方包名/版本白名单，没有 skip/omit/force/环境开关，没有弱化完整性、peer 或声明形态合同。该静态审查与真实 DSH 安装/销毁证据分别交付；不把本机 PASS 当作 Windows/Linux 真机验收，也不保证历史 pnpm 挂起在所有环境消失。
